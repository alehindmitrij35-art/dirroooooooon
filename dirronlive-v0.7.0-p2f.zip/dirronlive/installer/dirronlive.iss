﻿; Dirronlive - Inno Setup 6 installer script.
; Build: "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" installer\dirronlive.iss
; (run after "flutter build windows --release" and tools\bundle_vcruntime.ps1)

#define AppName "Dirronlive"
#define AppVersion "0.5.0"
#define AppExe "dirronlive.exe"
#define SourceDir "..\build\windows\x64\runner\Release"

[Setup]
AppId={{6F1B2C3D-8A4E-4B7F-9C21-D1E5A7B3C9F0}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher=Dirron
DefaultDirName={localappdata}\Programs\{#AppName}
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
; Installs for the current user only: no administrator rights needed.
PrivilegesRequired=lowest
OutputDir=..\build\installer
OutputBaseFilename=DirronliveSetup-{#AppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
SetupIconFile=..\assets\icon\app_icon.ico
UninstallDisplayIcon={app}\dirronlive.ico
; Просим Windows обновить кэш значков после установки (иначе ярлык может
; показывать старый значок предыдущей версии).
ChangesAssociations=yes
UninstallDisplayName={#AppName}

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"

[Files]
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
; Отдельный файл значка для ярлыков: новый путь — Windows не возьмёт старую картинку из кэша.
Source: "..\assets\icon\app_icon.ico"; DestDir: "{app}"; DestName: "dirronlive.ico"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\{#AppName}"; Filename: "{app}\{#AppExe}"; IconFilename: "{app}\dirronlive.ico"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExe}"; IconFilename: "{app}\dirronlive.ico"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExe}"; Description: "{cm:LaunchProgram,{#AppName}}"; Flags: nowait postinstall skipifsilent

; User data (%APPDATA%\Dirronlive: nickname and event history) is kept on uninstall.
