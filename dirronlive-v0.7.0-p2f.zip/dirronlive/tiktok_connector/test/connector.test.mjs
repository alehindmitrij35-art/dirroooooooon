import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { userRoles, avatarUrl, classifyError, normalizeCatalog, normalizeChat, normalizeGift, normalizeLike, parseArgs, parsePublicGiftList, publicGiftListUrl, toJsonLine } from '../lib.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const connector = path.join(here, '..', 'connector.mjs');
const fakeLib = new URL('./fake-lib.mjs', import.meta.url).href;

// По умолчанию общий список TikTok «недоступен» — проверяются запасные пути.
const PUBLIC_DOWN = 'data:application/json,{"status_code":5}';

function run(args, scenario, { closeStdinAfter, writeAfter, giftList = PUBLIC_DOWN } = {}) {
  return new Promise((resolve) => {
    const child = spawn(process.execPath, [connector, ...args], {
      env: { ...process.env, DIRRONLIVE_TIKTOK_LIB: fakeLib, DIRRONLIVE_FAKE_SCENARIO: scenario,
        DIRRONLIVE_GIFT_LIST_URL: giftList },
    });
    let out = '';
    child.stdout.on('data', (d) => { out += d; });
    if (writeAfter) setTimeout(() => child.stdin.write(writeAfter.text), writeAfter.ms);
    if (closeStdinAfter) setTimeout(() => child.stdin.end(), closeStdinAfter);
    child.on('exit', (code) => resolve({
      code,
      lines: out.trim().split('\n').filter(Boolean).map((l) => JSON.parse(l)),
    }));
  });
}

test('normalizeGift: поля, BigInt и запасные варианты', () => {
  const g = normalizeGift({
    common: { msgId: 123456789012345678n }, giftId: 5655, groupId: 99n, repeatCount: 3,
    repeatEnd: 1, giftDetails: { giftName: 'Rose', giftType: 1 },
    user: { userId: 1n, uniqueId: 'u', nickname: 'Ник' },
  });
  assert.equal(g.msgId, '123456789012345678');
  assert.equal(g.groupId, '99');
  assert.equal(g.giftName, 'Rose');
  assert.equal(g.streakable, true);
  assert.equal(g.repeatEnd, true);
  assert.equal(g.repeatCount, 3);
  assert.equal(g.nickname, 'Ник');
  assert.equal(normalizeGift({ groupId: 0n }).groupId, null);
  assert.equal(normalizeGift({}).repeatCount, 1);
});

test('classifyError: эфир не найден, сеть, сервис', () => {
  class UserOfflineError extends Error { constructor() { super("isn't online"); this.name = 'UserOfflineError'; } }
  assert.equal(classifyError(new UserOfflineError()).status, 'offline');
  const net = new Error('connect ECONNREFUSED'); net.code = 'ECONNREFUSED';
  assert.equal(classifyError(net).kind, 'network');
  const rl = new Error('Too many'); rl.name = 'SignatureRateLimitError';
  assert.match(classifyError(rl).message, /Euler Stream/);
  assert.equal(classifyError(new Error('boom')).kind, 'service');
});

test('parseArgs и BigInt в JSON', () => {
  assert.deepEqual(parseArgs(['--user', ' @dirron ', '--key', 'k']), { user: 'dirron', key: 'k', selfCheck: false, fetchGifts: false, lang: 'ru-RU' });
  assert.equal(toJsonLine({ a: 1n }), '{"a":"1"}');
});

test('процесс: подключение, серия, одиночный подарок, конец эфира', async () => {
  const { code, lines } = await run(['--user', '@dirron'], 'gifts');
  assert.equal(code, 0);
  assert.deepEqual(lines[0], { type: 'status', status: 'connecting', uniqueId: 'dirron' });
  const connected = lines.find((l) => l.status === 'connected');
  assert.equal(connected.roomId, '7300000000000000001');
  const gifts = lines.filter((l) => l.type === 'gift');
  assert.equal(gifts.length, 7);
  assert.deepEqual(gifts.slice(0, 6).map((g) => g.repeatCount), [1, 2, 3, 4, 5, 5]);
  assert.equal(gifts[5].repeatEnd, true);
  assert.equal(gifts[5].groupId, '777');
  assert.equal(gifts[6].streakable, false);
  assert.equal(gifts[6].nickname, 'Alex');
  assert.equal(lines.at(-1).status, 'ended');
});

test('процесс: эфир не найден', async () => {
  const { lines } = await run(['--user', 'dirron'], 'offline');
  assert.equal(lines.at(-1).status, 'offline');
});

test('процесс: ошибка сети', async () => {
  const { code, lines } = await run(['--user', 'dirron'], 'network');
  assert.equal(code, 1);
  assert.equal(lines.at(-1).kind, 'network');
});

test('процесс: обрыв связи', async () => {
  const { lines } = await run(['--user', 'dirron'], 'drop');
  assert.equal(lines.at(-1).status, 'disconnected');
});

test('процесс: выходит, когда Dirronlive закрыл stdin', async () => {
  const { code, lines } = await run(['--user', 'dirron'], 'idle', { closeStdinAfter: 200 });
  assert.equal(code, 0);
  assert.equal(lines.filter((l) => l.type === 'status').at(-1).status, 'connected');
  assert.ok(lines.some((l) => l.type === 'room'));
});

test('процесс: каталог подарков приходит сам после подключения и по запросу «gifts»', async () => {
  const { lines } = await run(['--user', 'dirron'], 'idle',
    { writeAfter: { text: 'gifts\n', ms: 150 }, closeStdinAfter: 400 });
  const catalogs = lines.filter((l) => l.type === 'gifts');
  assert.equal(catalogs.length, 2);
  assert.deepEqual(catalogs.map((c) => c.where), ['connect', 'request']);
  assert.equal(catalogs[0].source, 'live');
  assert.deepEqual(catalogs[0].gifts.map((g) => g.id), ['5655', '5487']);
});

test('процесс: каталог без подключения не дали — берём его через подключение к эфиру', async () => {
  const { code, lines } = await run(['--fetch-gifts', '--user', 'dirron'], 'needs-connect');
  assert.equal(code, 0);
  assert.equal(lines.at(-1).type, 'gifts');
  assert.equal(lines.at(-1).gifts.length, 2);
});

test('процесс: каталог недоступен — понятная ошибка со всеми попытками', async () => {
  const { code, lines } = await run(['--fetch-gifts', '--user', 'dirron'], 'no-catalog');
  assert.equal(code, 1);
  const last = lines.at(-1);
  assert.equal(last.type, 'status');
  assert.ok(last.attempts.some((a) => a.includes('fetchAvailableGifts')), JSON.stringify(last));
  const live = await run(['--user', 'dirron'], 'no-catalog', { closeStdinAfter: 300 });
  const err = live.lines.find((l) => l.type === 'giftsError');
  assert.ok(err, JSON.stringify(live.lines));
  assert.ok(err.attempts.length >= 1);
});

test('процесс: самопроверка библиотеки', async () => {
  const { code, lines } = await run(['--self-check'], 'gifts');
  assert.equal(code, 0);
  assert.equal(lines[0].ok, true);
});

test('normalizeCatalog: ID строкой, без повторов и пустых', () => {
  const list = normalizeCatalog([
    { id: 5655n, name: 'Rose', diamond_count: 1, image: { url_list: ['https://x/rose.png'] } },
    { id: 5655, name: 'Rose' },
    { id: 0, name: 'Zero' },
    { id: 1, name: '  ' },
    { giftId: 7934, giftName: 'Heart Me', diamondCount: 1, icon: { urlList: ['https://x/h.png'] } },
  ]);
  assert.deepEqual(list, [
    { id: '5655', name: 'Rose', diamonds: 1, image: 'https://x/rose.png' },
    { id: '7934', name: 'Heart Me', diamonds: 1, image: 'https://x/h.png' },
  ]);
  assert.deepEqual(normalizeCatalog(null), []);
  assert.equal(parseArgs(['--fetch-gifts', '--user', '@a']).fetchGifts, true);
});

test('процесс: каталог подарков эфира', async () => {
  const { code, lines } = await run(['--fetch-gifts', '--user', '@dirron'], 'gifts');
  assert.equal(code, 0);
  assert.equal(lines.length, 1);
  assert.equal(lines[0].type, 'gifts');
  assert.deepEqual(lines[0].gifts.map((g) => g.id), ['5655', '5487']);
  assert.equal(lines[0].gifts[0].image, 'https://example.test/rose.png');
});

test('процесс: каталог, когда эфира нет', async () => {
  const { code, lines } = await run(['--fetch-gifts', '--user', 'dirron'], 'offline');
  assert.equal(code, 1);
  assert.equal(lines.at(-1).status, 'offline');
});

test('процесс: лайки, подписка, чат и сведения об эфире', async () => {
  const { lines } = await run(['--user', 'dirron'], 'social');
  const room = lines.find((l) => l.type === 'room');
  assert.equal(room.startTime, 1700000000);
  assert.equal(room.followers, 5321);
  const like = lines.find((l) => l.type === 'like');
  assert.equal(like.likeCount, 15);
  assert.equal(like.nickname, 'Mira');
  assert.equal(lines.find((l) => l.type === 'follow').userId, '7');
  assert.equal(lines.find((l) => l.type === 'chat').comment, '1');
});

test('подарок: цена и картинка', () => {
  const g = normalizeGift({ giftId: 5655, repeatCount: 1,
    giftDetails: { giftName: 'Rose', giftType: 1, diamondCount: 1, giftImage: { giftPictureUrl: 'https://x/r.webp' } } });
  assert.equal(g.diamondCount, 1);
  assert.equal(g.giftImage, 'https://x/r.webp');
  const plain = normalizeGift({ giftId: 1, giftDetails: { giftName: 'X', image: { url_list: ['https://x/a.png'] } } });
  assert.equal(plain.giftImage, 'https://x/a.png');
});

test('аватарка зрителя: из любого поля протокола, https в приоритете', () => {
  assert.equal(avatarUrl({ profilePicture: { url: ['http://a/1.webp', 'https://p16-sign.tiktokcdn.com/a.webp'] } }),
    'https://p16-sign.tiktokcdn.com/a.webp');
  assert.equal(avatarUrl({ avatarThumb: { urlList: ['https://x/t.jpg'] } }), 'https://x/t.jpg');
  assert.equal(avatarUrl({ profilePictureUrl: 'https://x/p.jpg' }), 'https://x/p.jpg');
  assert.equal(avatarUrl({}), null);
  assert.equal(avatarUrl({ profilePicture: { url: ['not a url'] } }), null);
  const user = { uniqueId: 'mira', nickname: 'Mira', profilePicture: { url: ['https://x/m.jpg'] } };
  assert.equal(normalizeGift({ user, giftId: 5655 }).avatar, 'https://x/m.jpg');
  assert.equal(normalizeLike({ user, likeCount: 3 }).avatar, 'https://x/m.jpg');
  assert.equal(normalizeChat({ user, comment: 'hi' }).avatar, 'https://x/m.jpg');
});

test('общий список подарков TikTok: адрес без эфира и разбор ответа', () => {
  const url = new URL(publicGiftListUrl('ru-RU'));
  assert.equal(url.host, 'webcast.tiktok.com');
  assert.equal(url.pathname, '/webcast/gift/list/');
  assert.equal(url.searchParams.get('webcast_language'), 'ru-RU');
  assert.equal(url.searchParams.get('room_id'), null, 'эфир не нужен');
  assert.equal(new URL(publicGiftListUrl('evil&x=1')).searchParams.get('webcast_language'), 'ru-RU');
  const gifts = parsePublicGiftList({ status_code: 0, data: { gifts: [
    { id: 5655, name: 'Роза', diamond_count: 1, image: { url_list: ['https://p16-webcast.tiktokcdn.com/rose.webp'] } },
    { id: 9427, name: 'Пегас', diamond_count: 42999, icon: { url_list: ['https://p16-webcast.tiktokcdn.com/p.webp'] } },
    { id: 5655, name: 'Роза', diamond_count: 1 },
  ] } });
  assert.deepEqual(gifts.map((g) => [g.id, g.name, g.diamonds]), [['5655', 'Роза', 1], ['9427', 'Пегас', 42999]]);
  assert.equal(gifts[0].image, 'https://p16-webcast.tiktokcdn.com/rose.webp');
  assert.throws(() => parsePublicGiftList({ status_code: 10011, data: { message: 'bad' } }), /10011/);
  assert.throws(() => parsePublicGiftList({ status_code: 0, data: { gifts: [] } }), /пустой/);
  assert.equal(parseArgs(['--fetch-gifts', '--lang', 'en-US']).lang, 'en-US');
  assert.equal(parseArgs(['--fetch-gifts']).user, null);
});

const PUBLIC_OK = 'data:application/json,' + encodeURIComponent(JSON.stringify({ status_code: 0, data: { gifts: [
  { id: 5655, name: 'Роза', diamond_count: 1, image: { url_list: ['https://x/rose.webp'] } },
  { id: 9427, name: 'Пегас', diamond_count: 42999, image: { url_list: ['https://x/p.webp'] } },
  { id: 6064, name: 'GG', diamond_count: 1, image: { url_list: ['https://x/gg.webp'] } },
] } }));

test('процесс: полный каталог без ника и без эфира', async () => {
  const { code, lines } = await run(['--fetch-gifts'], 'offline', { giftList: PUBLIC_OK });
  assert.equal(code, 0);
  assert.equal(lines.length, 1);
  assert.equal(lines[0].type, 'gifts');
  assert.equal(lines[0].source, 'public');
  assert.deepEqual(lines[0].gifts.map((g) => g.name), ['Роза', 'Пегас', 'GG']);
});

test('процесс: в эфире каталог тоже полный, а без общего списка — каталог комнаты', async () => {
  const live = await run(['--user', 'dirron'], 'gifts', { giftList: PUBLIC_OK, closeStdinAfter: 300 });
  const first = live.lines.find((l) => l.type === 'gifts');
  assert.equal(first.how, 'webcast/gift/list');
  assert.equal(first.gifts.length, 3);
  const down = await run(['--fetch-gifts'], 'gifts');
  assert.equal(down.code, 1, 'без ника запасного пути нет — понятная ошибка');
  assert.match(down.lines.at(-1).attempts[0], /webcast\/gift\/list/);
});

test('серийный подарок по флагу combo (новый протокол без giftType)', () => {
  assert.equal(normalizeGift({ giftId: 5655, gift: { combo: true }, repeatCount: 15, groupId: '7' }).streakable, true);
  assert.equal(normalizeGift({ giftId: 5655, giftDetails: { giftType: 1 } }).streakable, true);
  assert.equal(normalizeGift({ giftId: 9427, gift: { combo: false, type: 2 } }).streakable, false);
});

test('статус зрителя: подписчик, фан-клуб, платная подписка, модератор', () => {
  assert.deepEqual(userRoles({ user: { followInfo: { followStatus: 1 } } }),
    { follower: true, fan: false, subscriber: false, moderator: false });
  assert.equal(userRoles({ user: { fansClub: { data: { level: 3 } } } }).fan, true);
  assert.equal(userRoles({ user: { badges: [{ type: 'fans_club', level: 2 }] } }).fan, true);
  assert.equal(userRoles({ isSubscriber: true }).subscriber, true);
  assert.equal(userRoles({ isModerator: true }).moderator, true);
  assert.equal(userRoles({ followRole: 2 }).follower, true, 'взаимная подписка — тоже подписчик');
  assert.deepEqual(userRoles({}), { follower: false, fan: false, subscriber: false, moderator: false });
  const chat = normalizeChat({ user: { uniqueId: 'mira', followInfo: { followStatus: 1 } }, comment: 'hi' });
  assert.equal(chat.follower, true);
});
