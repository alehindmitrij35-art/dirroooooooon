// Экран «Режимы → Dirron Parkour: 100 комнат»: карточки сразу на экране,
// подарок из каталога одним нажатием, «Проверить в игре», «Добавить
// действие» и серия ×1000 — против «мода 2.0» без сокетов.

import 'dart:async';

import 'package:dirronlive/features/events/event_log.dart';
import 'package:dirronlive/features/minecraft/link_protocol.dart';
import 'package:dirronlive/features/minecraft/link_state.dart';
import 'package:dirronlive/features/minecraft/minecraft_link.dart';
import 'package:dirronlive/features/parkour/parkour_rules.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/memory_store.dart';
import 'support/test_app.dart';

/// Связь «как с модом 2.0 на карте»: очередь принимает только прирост
/// «всего», каждое срабатывание выполняется один раз.
class ParkourFakeLink extends FakeLinkController {
  ParkourFakeLink(super.initial);

  final StreamController<ModActionResult> _results = StreamController<ModActionResult>.broadcast();
  final List<Map<String, Object?>> sent = [];
  final Map<String, int> accepted = {};
  int executed = 0;
  int room = 5;

  @override
  Stream<ModActionResult> get actionResults => _results.stream;

  @override
  bool sendAction({
    required String id,
    required String action,
    required Map<String, Object?> params,
    required String label,
    required String viewerName,
    required bool test,
    int total = 1,
  }) {
    sent.add({'id': id, 'action': action, 'params': params, 'test': test, 'total': total});
    final from = room;
    final delta = total - (accepted[id] ?? 0);
    if (delta > 0) accepted[id] = total;
    for (var i = 0; i < delta; i++) {
      executed++;
      final rooms = (params['rooms'] as num?)?.toInt() ?? 1;
      switch (action) {
        case 'room_back':
          room = room - rooms < 1 ? 1 : room - rooms;
        case 'to_first_level':
          room = 1;
        case 'to_last_level':
          room = 100;
        case 'goto_room':
          room = (params['room'] as num?)?.toInt() ?? room;
      }
    }
    final done = accepted[id] ?? 0;
    final text = action == 'push' ? 'Толчок влево${done > 1 ? ' ×$done' : ''}' : 'Комната $from → $room';
    scheduleMicrotask(() {
      _results.add(ModActionResult(
          id: id, ok: true, result: text, room: room, accepted: done, done: done, queued: 0, finished: true));
      state = state.copyWith(parkour: ParkourInfo(available: true, room: room));
    });
    return true;
  }

  @override
  bool sendCountdown(String id, String title, int seconds) => true;
}

const _ready = MinecraftLinkState(
  phase: LinkPhase.worldReady,
  port: 8765,
  modVersion: '2.1.0',
  parkourActions: true,
  actionQueue: true,
  parkour: ParkourInfo(available: true, room: 5),
);

/// Каталог эфира с «Розой» (без картинки — нейтральный значок).
MemoryJsonStore _storeWithCatalog() => MemoryJsonStore()
  ..files['gift_catalog.json'] =
      '{"version":1,"fetchedAt":"2026-11-23T10:00:00Z","streamer":"dirron",'
          '"gifts":[{"id":"5655","name":"Rose","diamonds":1},{"id":"5487","name":"Finger Heart","diamonds":5}]}';

Future<void> _tap(WidgetTester tester, Finder finder) async {
  await tester.ensureVisible(finder);
  await tester.pumpAndSettle();
  await tester.tap(finder);
  await tester.pumpAndSettle();
}

void main() {
  for (final size in const [Size(1920, 1080), Size(1024, 700)]) {
    testWidgets('${size.width.toInt()}×${size.height.toInt()}: карточки, роза из каталога, проверка в игре',
        (tester) async {
      late ParkourFakeLink link;
      final container = await pumpDirronlive(
        tester,
        _storeWithCatalog(),
        size: size,
        overrides: [
          minecraftLinkProvider.overrideWith(() => link = ParkourFakeLink(_ready)),
        ],
      );

      await openSection(tester, 'modes');
      await _tap(tester, find.byKey(const ValueKey('open-dirron_parkour_100')));
      expectNoFlutterError(tester, 'экран паркура');

      // Сразу видны четыре готовые карточки.
      for (final id in ['push', 'super_push', 'to_first_level', 'to_last_level']) {
        expect(find.byKey(Key('rule-card-$id')), findsOneWidget, reason: id);
      }
      expect(find.text('СУПЕР СИЛЬНЫЙ ТОЛЧОК'), findsOneWidget);
      expect(find.textContaining('комната 5 из 100'), findsOneWidget);

      // Подарок для «Толчка» — одним нажатием в каталоге.
      await _tap(tester, find.byKey(const Key('rule-gift-card-push')));
      expect(find.byKey(const Key('gift-catalog')), findsOneWidget);
      expect(find.text('Роза'), findsWidgets);
      expectNoFlutterError(tester, 'каталог при выборе подарка');
      expect(find.byKey(const Key('gift-option-likes')), findsOneWidget);
      expect(find.byKey(const Key('gift-option-follow')), findsOneWidget);
      await _tap(tester, find.byKey(const Key('gift-option-5655')));
      expect(find.byKey(const Key('gift-catalog')), findsNothing);
      final push = container.read(parkourRulesProvider).rules.firstWhere((r) => r.id == 'card-push');
      expect(push.giftName, 'Роза');
      expect(push.giftId, '5655');
      expect(find.byKey(const Key('rule-gift-name-card-push')), findsOneWidget);
      expect(
          tester.widget<Text>(find.byKey(const Key('rule-gift-name-card-push'))).data, 'Роза');

      // Перейти в комнату 12 и проверить «На первый уровень».
      await tester.ensureVisible(find.byKey(const Key('parkour-room-field')));
      await tester.pumpAndSettle();
      await tester.enterText(find.byKey(const Key('parkour-room-field')), '12');
      await _tap(tester, find.byKey(const Key('parkour-goto')));
      expect(find.text('Комната 5 → 12'), findsOneWidget);
      await _tap(tester, find.byKey(const Key('rule-test-card-to_first_level')));
      expectNoFlutterError(tester, 'после проверки');
      expect(find.text('Тест · Комната 12 → 1'), findsWidgets);
      expect(link.room, 1);
      expect(container.read(eventLogProvider).events.first.actionText, 'Тест · Комната 12 → 1');

      // «Добавить действие» → окно с 23 действиями → «Комната назад».
      await _tap(tester, find.byKey(const Key('add-action')));
      expect(find.byKey(const Key('action-picker')), findsOneWidget);
      // Список длинный (сетка строится по мере прокрутки) — последнее действие ищем поиском.
      await tester.enterText(find.byKey(const Key('action-picker-search')), 'супер');
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('pick-action-super_push')), findsOneWidget);
      await tester.enterText(find.byKey(const Key('action-picker-search')), 'назад');
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('pick-action-to_last_level')), findsNothing);
      await _tap(tester, find.byKey(const Key('pick-action-room_back')));
      final rules = container.read(parkourRulesProvider).rules;
      expect(rules, hasLength(5));
      expect(rules.last.actionId, 'room_back');

      // Серия ×1000 на «Толчке»: ровно 1000 срабатываний.
      await _tap(tester, find.byKey(const Key('rule-series-card-push')));
      for (var i = 0; i < 40; i++) {
        await tester.pump(const Duration(milliseconds: 100));
      }
      await tester.pumpAndSettle();
      expect(link.executed, 1 + 1 + 1000, reason: 'переход, проверка, серия');
      final status = tester.widget<Text>(find.byKey(const Key('rule-status-card-push'))).data!;
      expect(status, contains('принято 1\u00A0000, выполнено 1\u00A0000, в очереди 0'));

      // История: записи проверок.
      await openSection(tester, 'history');
      expect(find.text('Тест · Комната 12 → 1'), findsOneWidget);

      await closeDirronlive(tester, container);
    });
  }

  testWidgets('без мира кнопки показывают причину, а не молчат', (tester) async {
    final container = await pumpDirronlive(
      tester,
      MemoryJsonStore(),
      size: const Size(1024, 700),
      overrides: [fakeLink(const MinecraftLinkState())],
    );
    await openSection(tester, 'modes');
    await _tap(tester, find.byKey(const ValueKey('open-dirron_parkour_100')));
    expect(find.textContaining('Связь с игрой выключена'), findsOneWidget);
    await _tap(tester, find.byKey(const Key('rule-test-card-push')));
    expect(find.byKey(const Key('rule-status-card-push')), findsOneWidget);
    expect(container.read(eventLogProvider).events, isEmpty);

    // Каталог ещё не скачан: подсказка, что эфир не нужен; популярные подарки по названию.
    await _tap(tester, find.byKey(const Key('open-gift-catalog')));
    expect(find.textContaining('эфир для этого не нужен'), findsOneWidget);
    expect(find.byKey(const Key('gift-option-Роза')), findsOneWidget);
    await _tap(tester, find.byKey(const Key('gift-catalog-close')));

    // Назад к сетке режимов.
    await _tap(tester, find.byKey(const Key('parkour-back')));
    expect(find.byKey(const ValueKey('mode-maze_escape')), findsOneWidget);
    await closeDirronlive(tester, container);
  });
}
