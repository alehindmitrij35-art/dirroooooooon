import 'package:dirronlive/core/events/event_source.dart';
import 'package:dirronlive/core/events/gift_event.dart';
import 'package:dirronlive/core/events/stream_events.dart';
import 'package:dirronlive/core/providers.dart';
import 'package:dirronlive/features/chat/chat_settings.dart';
import 'package:dirronlive/features/chat/chat_voice.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/memory_store.dart';

class FakeSpeaker extends ChatSpeaker {
  final said = <String>[];

  @override
  Future<String> say(SpeechLine line, ChatSettings settings) async {
    said.add(line.text);
    return 'тест';
  }

  @override
  Future<void> dispose() async {}
}

/// Говорилка с задержками: видно, что следующая фраза готовится, пока звучит текущая.
class SlowSpeaker extends ChatSpeaker {
  SlowSpeaker({this.prepareMs = 80, this.sayMs = 120});

  final int prepareMs;
  final int sayMs;
  final log = <String>[];

  @override
  Future<Object?> prepare(SpeechLine line, ChatSettings settings) async {
    log.add('готовлю ${line.text}');
    await Future<void>.delayed(Duration(milliseconds: prepareMs));
    log.add('готово ${line.text}');
    return line.text;
  }

  @override
  Future<String> sayPrepared(SpeechLine line, ChatSettings settings, Object? prepared) async {
    log.add('говорю $prepared');
    await Future<void>.delayed(Duration(milliseconds: sayMs));
    log.add('сказал $prepared');
    return 'тест';
  }

  @override
  Future<String> say(SpeechLine line, ChatSettings settings) async =>
      sayPrepared(line, settings, await prepare(line, settings));

  @override
  Future<void> dispose() async {}
}

ProviderContainer _voiceContainer(ChatSpeaker speaker) => ProviderContainer(overrides: [
      jsonStoreProvider.overrideWithValue(MemoryJsonStore()),
      chatSpeakerProvider.overrideWithValue(speaker),
    ]);

Future<void> _until(bool Function() ok, {int ms = 4000}) async {
  final end = DateTime.now().add(Duration(milliseconds: ms));
  while (!ok()) {
    if (DateTime.now().isAfter(end)) fail('не дождались');
    await Future<void>.delayed(const Duration(milliseconds: 10));
  }
}

void main() {
  test('кого озвучивать: все, подписчики, фан-клуб, кто дарил, список; несколько групп сразу', () {
    const s = ChatSettings(allow: ['mira'], block: ['spam_bot']);
    final gifters = {'42'};
    const alex = ChatViewer(id: '1', name: 'Alex');
    const fan = ChatViewer(id: '2', name: 'Kate', fan: true);
    const follower = ChatViewer(id: '3', name: 'Bob', follower: true);
    const sub = ChatViewer(id: '4', name: 'Ann', subscriber: true);
    expect(s.passes({ChatWho.all}, alex, gifters), isTrue);
    expect(s.passes({ChatWho.all}, const ChatViewer(id: '9', name: 'Spam_Bot'), gifters), isFalse,
        reason: 'чёрный список сильнее всего');
    expect(s.passes({ChatWho.followers}, follower, gifters), isTrue);
    expect(s.passes({ChatWho.followers}, alex, gifters), isFalse);
    expect(s.passes({ChatWho.fans}, fan, gifters), isTrue);
    expect(s.passes({ChatWho.fans}, follower, gifters), isFalse);
    expect(s.passes({ChatWho.subscribers}, sub, gifters), isTrue);
    expect(s.passes({ChatWho.followers, ChatWho.fans}, fan, gifters), isTrue, reason: 'любая из групп');
    expect(s.passes({ChatWho.followers, ChatWho.fans}, alex, gifters), isFalse);
    expect(s.passes({ChatWho.gifters}, const ChatViewer(id: '42', name: 'X'), gifters), isTrue);
    expect(s.passes({ChatWho.listed}, const ChatViewer(id: '7', name: 'Mira'), gifters), isTrue);
    expect(s.passes({ChatWho.fans}, const ChatViewer(id: '7', name: 'Mira'), gifters), isTrue,
        reason: '«всегда» сильнее отбора');
    expect(ChatSettings.normalizeNames('@Mira, alex ;Котик\nmira'), ['mira', 'alex', 'котик']);
    expect(ChatWho.parse('gifters'), {ChatWho.gifters}, reason: 'старый формат настроек');
    expect(ChatWho.parse(['fans', 'followers']), {ChatWho.fans, ChatWho.followers});
    expect(ChatWho.parse(null), {ChatWho.all});
  });

  test('настройки сохраняются и читаются, неверные значения ограничены', () {
    final s = const ChatSettings().copyWith(
        voice: true, voiceWho: {ChatWho.fans, ChatWho.followers}, voiceName: 'ru-RU-DmitryNeural', rate: 30, allow: ['mira']);
    final back = ChatSettings.fromJson(s.toJson());
    expect(back.voice, isTrue);
    expect(back.voiceWho, {ChatWho.fans, ChatWho.followers});
    expect(back.voiceName, 'ru-RU-DmitryNeural');
    expect(back.rate, 30);
    expect(back.allow, ['mira']);
    final bad = ChatSettings.fromJson({'rate': 999, 'volume': -5, 'voiceName': 'evil'});
    expect(bad.rate, 100);
    expect(bad.volume, 0);
    expect(bad.voiceName, 'mix');
  });

  test('выразительная фраза: ник, «!» бодрее, «?» вопросом, КАПС громче и не по буквам, ссылки и эмодзи', () {
    const s = ChatSettings(voiceName: 'ru-RU-SvetlanaNeural', rate: 0);
    final plain = ChatSpeech.line('1', 'mira_love', 'привет', s)!;
    expect(plain.text, 'mira love: привет');
    expect(plain.pitch, 0);
    final excited = ChatSpeech.line('1', 'Mira', 'Ура, победа!', s)!;
    expect(excited.rate, greaterThan(0));
    expect(excited.pitch, greaterThan(0));
    expect(ChatSpeech.line('1', 'Mira', 'как дела?', s)!.pitch, greaterThan(0));
    final loud = ChatSpeech.line('1', 'Mira', 'ДАВАЙ БЫСТРЕЕ', s)!;
    expect(loud.volume, greaterThan(0));
    expect(loud.text, 'Mira: давай быстрее', reason: 'капс иначе читается по буквам');
    final link = ChatSpeech.line('1', 'Mira', 'смотри https://spam.example/x 😂', s)!;
    expect(link.text, contains('ссылка'));
    expect(link.text, contains('ха-ха'));
    expect(link.text, isNot(contains('http')));
    expect(ChatSpeech.line('1', 'Mira', 'ааааааа!!!!!!', s)!.text, 'Mira: ааа!!!');
    expect(ChatSpeech.line('1', 'Mira', '🙂🙂', s), isNull, reason: 'нечего говорить');
    final noName = ChatSpeech.line('1', 'Mira', 'привет', s.copyWith(readNames: false))!;
    expect(noName.text, 'привет');
    final long = ChatSpeech.line('1', 'M', 'а' * 50 + ' ' + 'б' * 300, s.copyWith(maxLength: 40))!;
    expect(long.text.length, lessThan(50));
  });

  test('«Разные голоса»: у каждого зрителя свой, и он не меняется', () {
    const s = ChatSettings(voiceName: 'mix');
    final voices = {
      for (final id in ['1', '2', '3', '4', '5', '6', '7', '8']) ChatSpeech.line(id, 'x', 'привет', s)!.voice,
    };
    expect(voices, containsAll(['ru-RU-SvetlanaNeural', 'ru-RU-DmitryNeural']));
    expect(ChatSpeech.line('5', 'x', 'привет', s)!.voice, ChatSpeech.line('5', 'y', 'пока', s)!.voice);
    final ssml = ChatSpeech.line('5', 'Mira', 'a < b & "c"', s)!.ssml();
    expect(ssml, contains('&lt;'));
    expect(ssml, contains('&amp;'));
    expect(ssml, contains("<prosody pitch='"));
  });

  test('пропуск нейроголоса: 64 знака, меняется раз в 5 минут', () {
    final a = EdgeTts.secMsGec(DateTime.utc(2026, 11, 24, 10, 0, 10));
    final b = EdgeTts.secMsGec(DateTime.utc(2026, 11, 24, 10, 4, 50));
    final c = EdgeTts.secMsGec(DateTime.utc(2026, 11, 24, 10, 5, 1));
    expect(a, hasLength(64));
    expect(a, a.toUpperCase());
    expect(a, b);
    expect(a, isNot(c));
  });

  test('чат озвучивается по настройкам «кого», при наплыве очередь не растёт бесконечно', () async {
    final speaker = FakeSpeaker();
    final c = ProviderContainer(overrides: [
      jsonStoreProvider.overrideWithValue(MemoryJsonStore()),
      chatSpeakerProvider.overrideWithValue(speaker),
    ]);
    await c.read(chatSettingsProvider.notifier).change(
        (s) => s.copyWith(minecraft: false, voice: true, voiceWho: {ChatWho.gifters, ChatWho.fans}, voiceName: 'windows'));
    c.read(chatRelayProvider);
    final bus = c.read(eventBusProvider);
    bus.publish(ChatEvent(viewerId: '1', viewerName: 'Alex', text: 'без подарка', source: EventSource.tiktok));
    bus.publish(GiftEvent(
        id: 'g1',
        createdAt: DateTime.now(),
        source: EventSource.tiktok,
        viewerName: 'Mira',
        viewerId: '42',
        giftName: 'Роза',
        count: 1));
    await Future<void>.delayed(const Duration(milliseconds: 20));
    bus.publish(ChatEvent(viewerId: '42', viewerName: 'Mira', text: 'спасибо!', source: EventSource.tiktok));
    await Future<void>.delayed(const Duration(milliseconds: 50));
    bus.publish(ChatEvent(viewerId: '7', viewerName: 'Kate', text: 'я фанат', source: EventSource.tiktok, isFan: true));
    await Future<void>.delayed(const Duration(milliseconds: 50));
    expect(speaker.said, ['Mira: спасибо!', 'Kate: я фанат'], reason: 'дарил подарок или в фан-клубе');
    c.dispose();
  });

  test('следующая фраза готовится, пока звучит текущая; история с задержкой и «Повторить»', () async {
    final speaker = SlowSpeaker();
    final c = _voiceContainer(speaker);
    await c.read(chatSettingsProvider.notifier).change((s) => s.copyWith(minecraft: false, voice: true, voiceName: 'windows'));
    c.read(chatRelayProvider);
    final bus = c.read(eventBusProvider);
    bus.publish(ChatEvent(viewerId: '1', viewerName: 'Alex', text: 'раз', source: EventSource.tiktok));
    bus.publish(ChatEvent(viewerId: '2', viewerName: 'Kate', text: 'два', source: EventSource.tiktok));
    await _until(() => c.read(voiceHistoryProvider).length == 2);
    final log = speaker.log;
    expect(log.indexOf('готовлю Kate: два'), lessThan(log.indexOf('сказал Alex: раз')),
        reason: 'синтез второй фразы идёт во время первой: $log');
    final history = c.read(voiceHistoryProvider);
    expect(history.first.viewer, 'Kate');
    expect(history.first.message, 'два');
    expect(history.first.status, 'spoken');
    expect(history.last.waitMs, greaterThanOrEqualTo(0));
    expect(c.read(voiceHistoryProvider.notifier).averageWaitMs(), isNotNull);

    c.read(chatRelayProvider.notifier).replay(history.last);
    await _until(() => c.read(voiceHistoryProvider).length == 3);
    expect(c.read(voiceHistoryProvider).first.message, 'раз');
    c.dispose();
  });

  test('сообщение, которое ждало дольше предела, пропускается с причиной', () async {
    final speaker = SlowSpeaker(prepareMs: 10, sayMs: 1300);
    final c = _voiceContainer(speaker);
    await c.read(chatSettingsProvider.notifier)
        .change((s) => s.copyWith(minecraft: false, voice: true, voiceName: 'windows', maxDelay: 1));
    c.read(chatRelayProvider);
    final bus = c.read(eventBusProvider);
    bus.publish(ChatEvent(viewerId: '1', viewerName: 'Alex', text: 'первое', source: EventSource.tiktok));
    bus.publish(ChatEvent(viewerId: '2', viewerName: 'Kate', text: 'второе', source: EventSource.tiktok));
    await _until(() => c.read(voiceHistoryProvider).length == 2);
    final kate = c.read(voiceHistoryProvider).firstWhere((e) => e.viewer == 'Kate');
    expect(kate.status, 'skipped');
    expect(kate.reason, contains('ждало дольше 1 с'));
    expect(speaker.log.where((l) => l.startsWith('говорю')), ['говорю Alex: первое']);
    c.dispose();
  });

  test('предел ожидания сохраняется и ограничен', () {
    expect(const ChatSettings().maxDelay, 15);
    final back = ChatSettings.fromJson(const ChatSettings(maxDelay: 30).toJson());
    expect(back.maxDelay, 30);
    expect(ChatSettings.fromJson({'maxDelay': 999}).maxDelay, 120);
    expect(ChatSettings.fromJson({'maxDelay': 0}).maxDelay, 0);
  });
}
