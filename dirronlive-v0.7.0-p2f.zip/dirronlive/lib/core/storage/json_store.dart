/// Хранилище JSON-документов по имени файла.
///
/// В приложении используется [FileJsonStore] (папка данных пользователя
/// Windows), в тестах — хранилище в памяти.
abstract interface class JsonStore {
  /// Где лежат данные (показывается в настройках).
  String get location;

  /// Читает документ. Возвращает `null`, если его ещё нет.
  ///
  /// Бросает [StorageException], если файл не удалось прочитать,
  /// и [FormatException], если содержимое повреждено.
  Future<Map<String, Object?>?> read(String name);

  /// Записывает документ целиком. Бросает [StorageException] при ошибке.
  Future<void> write(String name, Map<String, Object?> data);

  /// Откладывает повреждённый документ в сторону, чтобы не потерять его.
  /// Возвращает новое имя копии или `null`, если отложить не удалось.
  Future<String?> quarantine(String name);
}
