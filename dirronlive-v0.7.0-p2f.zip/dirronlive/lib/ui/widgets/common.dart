import 'package:flutter/material.dart';

import '../../core/events/delivery_status.dart';
import '../../core/events/event_source.dart';
import '../../features/connections/connections.dart';
import '../../features/minecraft/link_state.dart';
import '../../features/tiktok/tiktok_state.dart';
import '../theme/app_colors.dart';

/// Карточка на фоне #211D33.
class Panel extends StatelessWidget {
  const Panel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(20),
    this.borderColor,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? borderColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor ?? AppColors.border),
      ),
      child: child,
    );
  }
}

/// Заголовок экрана.
class PageHeader extends StatelessWidget {
  const PageHeader({super.key, required this.title, this.subtitle});

  final String title;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.headlineSmall),
        if (subtitle != null) ...[
          const SizedBox(height: 6),
          Text(
            subtitle!,
            style: Theme.of(context)
                .textTheme
                .bodyLarge
                ?.copyWith(color: AppColors.textMuted),
          ),
        ],
      ],
    );
  }
}

/// Прокручиваемый экран: при нехватке высоты всё содержимое,
/// включая кнопки, остаётся доступным прокруткой.
class SectionPage extends StatelessWidget {
  const SectionPage({
    super.key,
    required this.title,
    this.subtitle,
    required this.children,
  });

  final String title;
  final String? subtitle;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(32, 28, 32, 32),
      child: Align(
        alignment: Alignment.topLeft,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1180),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              PageHeader(title: title, subtitle: subtitle),
              const SizedBox(height: 24),
              ...children,
            ],
          ),
        ),
      ),
    );
  }
}

extension ConnectionStatusLook on ConnectionStatus {
  Color get color => switch (this) {
        ConnectionStatus.disconnected => AppColors.danger,
        ConnectionStatus.connecting => AppColors.warning,
        ConnectionStatus.connected => AppColors.success,
        ConnectionStatus.error => AppColors.danger,
      };

  IconData get icon => switch (this) {
        ConnectionStatus.disconnected => Icons.link_off_rounded,
        ConnectionStatus.connecting => Icons.sync_rounded,
        ConnectionStatus.connected => Icons.check_circle_rounded,
        ConnectionStatus.error => Icons.error_rounded,
      };
}

extension LinkPhaseLook on LinkPhase {
  Color get color => switch (this) {
        LinkPhase.off => AppColors.textFaint,
        LinkPhase.starting => AppColors.warning,
        LinkPhase.waitingForMod => AppColors.warning,
        LinkPhase.modConnected => AppColors.accent,
        LinkPhase.worldReady => AppColors.success,
        LinkPhase.error => AppColors.danger,
      };

  IconData get icon => switch (this) {
        LinkPhase.off => Icons.power_settings_new_rounded,
        LinkPhase.starting => Icons.sync_rounded,
        LinkPhase.waitingForMod => Icons.hourglass_top_rounded,
        LinkPhase.modConnected => Icons.link_rounded,
        LinkPhase.worldReady => Icons.public_rounded,
        LinkPhase.error => Icons.error_rounded,
      };
}

extension TikTokPhaseLook on TikTokPhase {
  Color get color => switch (this) {
        TikTokPhase.off => AppColors.textFaint,
        TikTokPhase.connecting => AppColors.warning,
        TikTokPhase.reconnecting => AppColors.warning,
        TikTokPhase.connected => AppColors.success,
        TikTokPhase.offline => AppColors.warning,
        TikTokPhase.ended => AppColors.textMuted,
        TikTokPhase.networkError => AppColors.danger,
        TikTokPhase.serviceError => AppColors.danger,
      };

  IconData get icon => switch (this) {
        TikTokPhase.off => Icons.power_settings_new_rounded,
        TikTokPhase.connecting => Icons.sync_rounded,
        TikTokPhase.reconnecting => Icons.sync_rounded,
        // Лаймовая точка рядом с «Подключено».
        TikTokPhase.connected => Icons.circle,
        TikTokPhase.offline => Icons.videocam_off_rounded,
        TikTokPhase.ended => Icons.stop_circle_rounded,
        TikTokPhase.networkError => Icons.wifi_off_rounded,
        TikTokPhase.serviceError => Icons.error_rounded,
      };
}

extension DeliveryStatusLook on DeliveryStatus {
  Color get color => switch (this) {
        DeliveryStatus.logOnly => AppColors.textMuted,
        DeliveryStatus.sending => AppColors.warning,
        DeliveryStatus.delivered => AppColors.success,
        DeliveryStatus.partial => AppColors.accentAlt,
        DeliveryStatus.unconfirmed => AppColors.danger,
      };

  IconData get icon => switch (this) {
        DeliveryStatus.logOnly => Icons.receipt_long_rounded,
        DeliveryStatus.sending => Icons.schedule_send_rounded,
        // Лаймовая галочка рядом с «Доставлено в игру».
        DeliveryStatus.delivered => Icons.check_rounded,
        DeliveryStatus.partial => Icons.incomplete_circle_rounded,
        DeliveryStatus.unconfirmed => Icons.help_outline_rounded,
      };
}

/// Статус: цвет + иконка + текст, читается одним взглядом.
class StatusPill extends StatelessWidget {
  const StatusPill({
    super.key,
    required this.label,
    required this.color,
    required this.icon,
    this.large = false,
  });

  StatusPill.connection(ConnectionStatus status, {Key? key, bool large = false})
      : this(
          key: key,
          label: status.label,
          color: status.color,
          icon: status.icon,
          large: large,
        );

  StatusPill.tiktok(TikTokState tiktok, {Key? key, bool large = false})
      : this(
          key: key,
          label: tiktok.label,
          color: tiktok.phase.color,
          icon: tiktok.phase.icon,
          large: large,
        );

  StatusPill.link(MinecraftLinkState link, {Key? key, bool large = false})
      : this(
          key: key,
          label: link.label,
          color: link.phase.color,
          icon: link.phase.icon,
          large: large,
        );

  final String label;
  final Color color;
  final IconData icon;
  final bool large;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: large ? 16 : 12,
        vertical: large ? 9 : 6,
      ),
      decoration: BoxDecoration(
        color: color.withAlpha(36),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withAlpha(120)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: icon == Icons.circle ? (large ? 12 : 10) : (large ? 20 : 16),
            color: color,
          ),
          SizedBox(width: large ? 10 : 8),
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: color,
                fontSize: large ? 17 : 14,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Статус доставки подарка в игру.
class DeliveryChip extends StatelessWidget {
  const DeliveryChip({super.key, required this.status, this.label});

  final DeliveryStatus status;

  /// Подпись вместо стандартной (например, «Доставлено 10 из 15»).
  final String? label;

  @override
  Widget build(BuildContext context) {
    final color = status.color;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withAlpha(30),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withAlpha(90)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(status.icon, size: 14, color: color),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              label ?? status.label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Метка источника события («Тест»).
class SourceChip extends StatelessWidget {
  const SourceChip({super.key, required this.source});

  final EventSource source;

  @override
  Widget build(BuildContext context) {
    final color =
        source == EventSource.test ? AppColors.accent : AppColors.accentAlt;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withAlpha(40),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        source.label,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: color,
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

/// Небольшая метка-тег (например, «В планах»).
class TagChip extends StatelessWidget {
  const TagChip({super.key, required this.label, this.color = AppColors.accentAlt});

  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withAlpha(36),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withAlpha(110)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

/// Строка «подпись — значение».
class InfoRow extends StatelessWidget {
  const InfoRow({super.key, required this.label, this.value, this.trailing});

  final String label;
  final String? value;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            width: 170,
            child: Text(
              label,
              style: const TextStyle(fontSize: 15, color: AppColors.textMuted),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Align(
              alignment: Alignment.centerLeft,
              child: trailing ??
                  Text(
                    value ?? '',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: AppColors.text,
                    ),
                  ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Пояснение о том, что появится на следующих этапах.
class NotePanel extends StatelessWidget {
  const NotePanel({super.key, required this.text, this.icon = Icons.info_outline_rounded});

  final String text;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Panel(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: AppColors.accent),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                fontSize: 14,
                height: 1.4,
                color: AppColors.textMuted,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Красная плашка с ошибкой.
class ErrorBanner extends StatelessWidget {
  const ErrorBanner({super.key, required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.danger.withAlpha(30),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.danger.withAlpha(140)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.warning_amber_rounded, color: AppColors.danger),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              message,
              style: const TextStyle(color: AppColors.text, height: 1.4),
            ),
          ),
        ],
      ),
    );
  }
}

/// Квадратная иконка с градиентом.
class IconBadge extends StatelessWidget {
  const IconBadge({super.key, required this.icon, this.size = 44});

  final IconData icon;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.28),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppColors.accent.withAlpha(60),
            AppColors.accentAlt.withAlpha(60),
          ],
        ),
      ),
      child: Icon(icon, color: AppColors.accent, size: size * 0.55),
    );
  }
}
