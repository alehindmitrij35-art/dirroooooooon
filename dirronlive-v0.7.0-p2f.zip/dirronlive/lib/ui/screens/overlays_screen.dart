import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/events/event_source.dart';
import '../../core/events/gift_event.dart';
import '../../core/providers.dart';
import '../../features/overlays/overlay_kind.dart';
import '../../features/overlays/overlay_models.dart';
import '../../features/overlays/overlay_server.dart';
import '../../features/overlays/overlay_settings.dart';
import '../../features/overlays/stream_stats.dart';
import '../theme/app_colors.dart';
import '../widgets/common.dart';
import 'overlays/overlay_config_dialog.dart';
import 'overlays/overlay_preview.dart';

/// «Оверлеи»: 13 рабочих виджетов для TikTok LIVE Studio. У каждого —
/// предпросмотр, «Настроить», «Тест» и «Скопировать ссылку».
class OverlaysScreen extends ConsumerWidget {
  const OverlaysScreen({super.key});

  static const message = 'Оверлеи для TikTok LIVE Studio и OBS';

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final server = ref.watch(overlayServerProvider);
    final settings = ref.watch(overlaySettingsProvider);
    final inputs = ref.watch(overlayInputsProvider);
    return SingleChildScrollView(
      key: const Key('overlays-area'),
      padding: const EdgeInsets.fromLTRB(32, 24, 32, 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const PageHeader(
            title: 'Оверлеи',
            subtitle: message,
          ),
          const SizedBox(height: 16),
          Panel(
            child: Wrap(
              spacing: 12,
              runSpacing: 10,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Icon(server.running ? Icons.check_circle_rounded : Icons.error_outline_rounded,
                    color: server.running ? AppColors.success : AppColors.warning, size: 20),
                Text(
                  server.running
                      ? 'Оверлеи работают. В TikTok LIVE Studio: «Добавить источник» → «Ссылка» → вставьте '
                          'скопированную ссылку. Ссылки постоянные, обновляются сами'
                      : (server.error ?? (server.starting ? 'Запускаю оверлеи…' : 'Сервер оверлеев не запущен')),
                  key: const Key('overlay-server-status'),
                  style: const TextStyle(fontSize: 14, color: AppColors.text),
                ),
                if (server.running && server.hostOk == null)
                  const Text('Проверяю ссылку для TikTok LIVE Studio…',
                      key: Key('overlay-host-checking'), style: TextStyle(fontSize: 13, color: AppColors.textMuted)),
                if (server.running && server.hostOk == true)
                  Text('Ссылка для TikTok LIVE Studio проверена: ${server.host}',
                      key: const Key('overlay-host-ok'),
                      style: const TextStyle(fontSize: 13, color: AppColors.success)),
                if (server.running && server.hostOk == false)
                  Text(server.hostProblem ?? '',
                      key: const Key('overlay-host-problem'),
                      style: const TextStyle(fontSize: 13, color: AppColors.warning)),
                if (!server.running && !server.starting)
                  OutlinedButton(
                    key: const Key('overlay-server-retry'),
                    onPressed: () => ref.read(overlayServerProvider.notifier).retry(),
                    child: Text(server.error == null ? 'Запустить' : 'Повторить'),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              FilterChip(
                key: const Key('overlay-test-mode'),
                selected: settings.testMode,
                showCheckmark: false,
                avatar: Icon(Icons.science_rounded,
                    size: 18, color: settings.testMode ? AppColors.onAccent : AppColors.textMuted),
                selectedColor: AppColors.warning,
                label: Text(settings.testMode ? 'Показываю тестовые данные' : 'Показываю реальный эфир',
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: settings.testMode ? AppColors.onAccent : AppColors.text)),
                onSelected: (v) => ref.read(overlaySettingsProvider.notifier).setTestMode(v),
              ),
              FilledButton.icon(
                key: const Key('overlay-test-series'),
                onPressed: () => _testSeries(ref),
                icon: const Icon(Icons.redeem_rounded, size: 18),
                label: const Text('Тестовая серия ×5'),
              ),
              OutlinedButton.icon(
                key: const Key('overlay-canvas'),
                onPressed: () => showDialog<void>(context: context, builder: (_) => const _CanvasDialog()),
                icon: const Icon(Icons.stay_current_portrait_rounded, size: 18),
                label: const Text('Холст 1080×1920'),
              ),
              TextButton(
                key: const Key('overlay-reset-test'),
                onPressed: () => ref.read(streamStatsProvider.notifier).resetTest(),
                child: const Text('Очистить тест'),
              ),
              TextButton(
                key: const Key('overlay-reset-live'),
                onPressed: () => ref.read(streamStatsProvider.notifier).resetLive(),
                child: const Text('Новый эфир: обнулить статистику'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          LayoutBuilder(builder: (context, c) {
            final columns = (c.maxWidth / 360).floor().clamp(1, 4).toInt();
            final width = (c.maxWidth - (columns - 1) * 14) / columns;
            return Wrap(
              spacing: 14,
              runSpacing: 14,
              children: [
                for (final kind in OverlayKind.values)
                  SizedBox(
                    width: width,
                    child: _OverlayCard(kind: kind, inputs: inputs, server: server),
                  ),
              ],
            );
          }),
        ],
      ),
    );
  }

  /// Серия «Роза ×1 → ×5» как в эфире, но в тестовом режиме: проходит
  /// через ту же ленту событий (цель, батл, комбо).
  static Future<void> _testSeries(WidgetRef ref) async {
    await ref.read(overlaySettingsProvider.notifier).setTestMode(true);
    final bus = ref.read(eventBusProvider);
    final comboId = 'overlay-test-${generateEventId()}';
    for (var n = 1; n <= 5; n++) {
      bus.publish(GiftEvent(
        id: generateEventId(),
        createdAt: DateTime.now(),
        source: EventSource.test,
        viewerName: 'Тестовый зритель',
        viewerId: 'test-viewer',
        giftName: 'Роза',
        giftId: '5655',
        diamonds: 1,
        count: n,
        comboId: comboId,
        comboActive: n < 5,
        sourceKey: comboId,
      ));
    }
  }
}

class _OverlayCard extends ConsumerWidget {
  const _OverlayCard({required this.kind, required this.inputs, required this.server});

  final OverlayKind kind;
  final OverlayInputs inputs;
  final OverlayServerState server;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final model = buildOverlayModel(kind, inputs);
    final issue = overlayDataIssue(kind, inputs);
    return Container(
      key: Key('overlay-${kind.slug}'),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(kind.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.text)),
          Text(kind.description, style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
          const SizedBox(height: 10),
          // Предпросмотр на «сцене»: шахматка показывает прозрачный фон.
          Container(
            height: 200,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: const Color(0xFF0B0812),
              border: Border.all(color: AppColors.border),
            ),
            clipBehavior: Clip.antiAlias,
            child: FittedBox(
              fit: BoxFit.contain,
              child: OverlayPreview(key: Key('preview-${kind.slug}'), model: model),
            ),
          ),
          if (issue != null) ...[
            const SizedBox(height: 8),
            Text(issue,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12, color: AppColors.warning)),
          ],
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              OutlinedButton.icon(
                key: Key('overlay-config-${kind.slug}'),
                onPressed: () => OverlayConfigDialog.show(context, kind),
                icon: const Icon(Icons.tune_rounded, size: 16),
                label: const Text('Настроить'),
              ),
              OutlinedButton.icon(
                key: Key('overlay-test-${kind.slug}'),
                onPressed: () async {
                  await ref.read(overlaySettingsProvider.notifier).setTestMode(true);
                  if (kind == OverlayKind.giftBattle &&
                      !ref.read(overlaySettingsProvider).get(kind, 'running', false)) {
                    await ref.read(overlaySettingsProvider.notifier).set(kind, 'running', true);
                    ref.read(streamStatsProvider.notifier).startBattle(test: true);
                  }
                  if (kind == OverlayKind.chatVote) {
                    await ref.read(overlaySettingsProvider.notifier).set(kind, 'running', true);
                  }
                  ref.read(streamStatsProvider.notifier).seedTest(kind);
                },
                icon: const Icon(Icons.science_rounded, size: 16),
                label: const Text('Тест'),
              ),
              FilledButton.icon(
                key: Key('overlay-copy-${kind.slug}'),
                onPressed: () async {
                  final link = server.linkFor(kind);
                  await Clipboard.setData(ClipboardData(text: link));
                  ref.read(noticeServiceProvider).info('Ссылка скопирована: $link');
                },
                icon: const Icon(Icons.link_rounded, size: 16),
                label: const Text('Скопировать ссылку'),
              ),
              TextButton(
                key: Key('overlay-copy-obs-${kind.slug}'),
                onPressed: () async {
                  final link = server.localLinkFor(kind);
                  await Clipboard.setData(ClipboardData(text: link));
                  ref.read(noticeServiceProvider).info('Ссылка для OBS скопирована: $link');
                },
                child: const Text('Для OBS'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Вертикальный холст 1080×1920: несколько оверлеев сразу, как в сцене.
class _CanvasDialog extends ConsumerStatefulWidget {
  const _CanvasDialog();

  @override
  ConsumerState<_CanvasDialog> createState() => _CanvasDialogState();
}

class _CanvasDialogState extends ConsumerState<_CanvasDialog> {
  final Set<OverlayKind> _shown = {OverlayKind.goal, OverlayKind.giftBattle};

  @override
  Widget build(BuildContext context) {
    final inputs = ref.watch(overlayInputsProvider);
    final screen = MediaQuery.sizeOf(context);
    final canvasHeight = (screen.height - 140).clamp(300.0, 1920.0).toDouble();
    final scale = canvasHeight / 1920;
    return Dialog(
      key: const Key('overlay-canvas-dialog'),
      backgroundColor: AppColors.surface,
      insetPadding: const EdgeInsets.all(20),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 240,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Холст 1080×1920',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppColors.text)),
                  const SizedBox(height: 4),
                  const Text('Отметьте, что показать в сцене.',
                      style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
                  const SizedBox(height: 8),
                  Expanded(
                    child: ListView(
                      shrinkWrap: true,
                      children: [
                        for (final k in OverlayKind.values)
                          CheckboxListTile(
                            dense: true,
                            value: _shown.contains(k),
                            title: Text(k.title, style: const TextStyle(fontSize: 13, color: AppColors.text)),
                            onChanged: (v) => setState(() => v == true ? _shown.add(k) : _shown.remove(k)),
                          ),
                      ],
                    ),
                  ),
                  TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Закрыть')),
                ],
              ),
            ),
            const SizedBox(width: 16),
            Container(
              width: 1080 * scale,
              height: canvasHeight,
              decoration: BoxDecoration(
                color: const Color(0xFF39404F),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              clipBehavior: Clip.antiAlias,
              child: FittedBox(
                fit: BoxFit.contain,
                alignment: Alignment.topCenter,
                child: SizedBox(
                  width: 1080,
                  height: 1920,
                  child: SingleChildScrollView(
                    physics: const NeverScrollableScrollPhysics(),
                    child: Column(
                      children: [
                        for (final k in OverlayKind.values)
                          if (_shown.contains(k)) OverlayPreview(model: buildOverlayModel(k, inputs), width: 1080),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
