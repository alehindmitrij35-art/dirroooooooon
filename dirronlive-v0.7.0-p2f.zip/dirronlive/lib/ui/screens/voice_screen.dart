import 'package:flutter/material.dart';

import '../widgets/common.dart';
import 'chat_settings_panel.dart';
import 'voice_history_panel.dart';

/// Отдельный экран «Озвучка»: озвучка чата TikTok и чат в Minecraft.
class VoiceScreen extends StatelessWidget {
  const VoiceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      key: const Key('voice-area'),
      padding: const EdgeInsets.fromLTRB(32, 24, 32, 32),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 900),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              PageHeader(
                title: 'Озвучка',
                subtitle: 'Озвучка чата TikTok и чат в Minecraft: кого озвучивать, голос, скорость, история',
              ),
              SizedBox(height: 20),
              Panel(child: ChatSettingsPanel()),
              SizedBox(height: 16),
              Panel(child: VoiceHistoryPanel()),
            ],
          ),
        ),
      ),
    );
  }
}
