import 'package:flutter/material.dart';

import 'app_colors.dart';

/// Общая тема Flutter для всех экранов: цвета, шрифты, кнопки, поля ввода.
ThemeData buildAppTheme() {
  const scheme = ColorScheme.dark(
    primary: AppColors.accent,
    onPrimary: AppColors.onAccent,
    secondary: AppColors.accentAlt,
    onSecondary: AppColors.onAccent,
    tertiary: AppColors.success,
    onTertiary: AppColors.onAccent,
    surface: AppColors.surface,
    onSurface: AppColors.text,
    onSurfaceVariant: AppColors.textMuted,
    surfaceContainerHighest: AppColors.surfaceHigh,
    outline: AppColors.border,
    outlineVariant: AppColors.border,
    error: AppColors.danger,
    onError: AppColors.onAccent,
  );

  final base = ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: AppColors.background,
  );

  final textTheme = base.textTheme
      .apply(bodyColor: AppColors.text, displayColor: AppColors.text)
      .copyWith(
        headlineSmall: const TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.w800,
          color: AppColors.text,
        ),
        titleLarge: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w800,
          color: AppColors.text,
        ),
        titleMedium: const TextStyle(
          fontSize: 17,
          fontWeight: FontWeight.w700,
          color: AppColors.text,
        ),
        bodyLarge: const TextStyle(fontSize: 15, color: AppColors.text),
        bodyMedium: const TextStyle(fontSize: 14, color: AppColors.text),
        bodySmall: const TextStyle(fontSize: 13, color: AppColors.textMuted),
        labelLarge: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
      );

  final buttonShape =
      RoundedRectangleBorder(borderRadius: BorderRadius.circular(12));

  return base.copyWith(
    textTheme: textTheme,
    dividerColor: AppColors.border,
    dividerTheme: const DividerThemeData(color: AppColors.border, space: 1),
    iconTheme: const IconThemeData(color: AppColors.textMuted),
    textSelectionTheme: const TextSelectionThemeData(
      cursorColor: AppColors.accent,
      selectionColor: Color(0x66A78BFA),
      selectionHandleColor: AppColors.accent,
    ),
    // Главные кнопки («Подключиться», «Тестовый подарок», «Сохранить»):
    // фиолетовый #A78BFA с тёмным текстом #160C26.
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: AppColors.accent,
        foregroundColor: AppColors.onAccent,
        disabledBackgroundColor: AppColors.surfaceHigh,
        disabledForegroundColor: AppColors.textFaint,
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
        shape: buttonShape,
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: AppColors.accent,
        side: const BorderSide(color: AppColors.accent),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
        shape: buttonShape,
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: AppColors.accent,
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
      ),
    ),
    snackBarTheme: const SnackBarThemeData(
      backgroundColor: AppColors.surfaceHigh,
      contentTextStyle: TextStyle(color: AppColors.text),
      behavior: SnackBarBehavior.floating,
    ),
  );
}

/// Оформление полей ввода в общем стиле.
InputDecoration appInputDecoration({
  required String label,
  String? hint,
  String? helper,
  IconData? icon,
}) {
  final border = OutlineInputBorder(
    borderRadius: BorderRadius.circular(12),
    borderSide: const BorderSide(color: AppColors.border),
  );
  return InputDecoration(
    labelText: label,
    hintText: hint,
    helperText: helper,
    helperMaxLines: 2,
    prefixIcon: icon == null ? null : Icon(icon),
    filled: true,
    fillColor: AppColors.background,
    labelStyle: const TextStyle(color: AppColors.textMuted),
    hintStyle: const TextStyle(color: AppColors.textFaint),
    helperStyle: const TextStyle(color: AppColors.textFaint),
    prefixIconColor: AppColors.accent,
    border: border,
    enabledBorder: border,
    focusedBorder: border.copyWith(
      borderSide: const BorderSide(color: AppColors.accent, width: 2),
    ),
  );
}
