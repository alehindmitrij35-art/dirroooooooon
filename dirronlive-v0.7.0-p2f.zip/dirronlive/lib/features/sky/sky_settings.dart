import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/events/gift_event.dart';
import '../../core/providers.dart';
import '../../core/storage/json_store.dart';
import '../parkour/parkour_rules.dart' show likesTriggerId, followTriggerId, likesPerTrigger;
import 'sky_catalog.dart';

/// Карточка действия «Небесного разлома»: подарок, включено ли, сила,
/// длительность, перезарядка и что делать с повтором. Карточек ровно 10 —
/// по одной на действие, все видны всегда.
class SkyCard {
  const SkyCard({
    required this.actionId,
    this.enabled = true,
    this.giftName = '',
    this.giftId,
    this.imageUrl,
    this.strength = 1.0,
    this.seconds = 0,
    this.cooldown = 0,
    this.repeat = 'extend',
    this.likesEvery = likesPerTrigger,
  });

  final String actionId;
  final bool enabled;
  final String giftName;
  final String? giftId;
  final String? imageUrl;

  /// Множитель силы 0.5–2 (1 — обычная).
  final double strength;

  /// 0 — как в моде по умолчанию.
  final int seconds;
  final int cooldown;

  /// extend / queue / ignore — см. [skyRepeatRules].
  final String repeat;

  /// Для карточки «Лайки»: сколько лайков зрителя дают одно срабатывание.
  final int likesEvery;

  SkyActionInfo get action => skyActionById(actionId)!;

  int get effectiveSeconds => seconds > 0 ? seconds : action.seconds;
  int get effectiveCooldown => cooldown > 0 ? cooldown : action.cooldown;

  bool get hasGift => giftName.trim().isNotEmpty || giftId != null;
  bool get isLikes => giftId == likesTriggerId;
  bool get isFollow => giftId == followTriggerId;

  /// id «подарка» лайков/подписки для этой карточки (в шине событий).
  String get socialTrigger => '${isLikes ? likesTriggerId : followTriggerId}:sky-$actionId';

  bool matches(GiftEvent event) {
    if (!hasGift) return false;
    if (isLikes || isFollow) return event.giftId == socialTrigger;
    final id = giftId;
    final eventId = event.giftId;
    if (id != null && eventId != null) return id == eventId;
    return _norm(giftName) == _norm(event.giftName);
  }

  static String _norm(String s) => s.trim().toLowerCase().replaceAll('ё', 'е');

  SkyCard copyWith({
    bool? enabled,
    String? giftName,
    String? giftId,
    String? imageUrl,
    bool clearGift = false,
    double? strength,
    int? seconds,
    int? cooldown,
    String? repeat,
    int? likesEvery,
  }) =>
      SkyCard(
        actionId: actionId,
        enabled: enabled ?? this.enabled,
        giftName: clearGift ? '' : (giftName ?? this.giftName),
        giftId: clearGift ? null : (giftId ?? this.giftId),
        imageUrl: clearGift ? null : (imageUrl ?? this.imageUrl),
        strength: strength ?? this.strength,
        seconds: seconds ?? this.seconds,
        cooldown: cooldown ?? this.cooldown,
        repeat: repeat ?? this.repeat,
        likesEvery: likesEvery ?? this.likesEvery,
      );

  Map<String, Object?> toJson() => {
        'actionId': actionId,
        'enabled': enabled,
        'giftName': giftName,
        if (giftId != null) 'giftId': giftId,
        if (imageUrl != null) 'imageUrl': imageUrl,
        'strength': strength,
        'seconds': seconds,
        'cooldown': cooldown,
        'repeat': repeat,
        if (likesEvery != likesPerTrigger) 'likesEvery': likesEvery,
      };

  static SkyCard? fromJson(Object? json) {
    if (json is! Map) return null;
    final id = json['actionId'];
    if (id is! String || skyActionById(id) == null) return null;
    double d(Object? v, double def, double lo, double hi) => v is num ? v.toDouble().clamp(lo, hi).toDouble() : def;
    int n(Object? v, int lo, int hi) => v is num ? v.toInt().clamp(lo, hi).toInt() : 0;
    final repeat = json['repeat'];
    final giftId = json['giftId'];
    final imageUrl = json['imageUrl'];
    final giftName = json['giftName'];
    return SkyCard(
      actionId: id,
      enabled: json['enabled'] != false,
      giftName: giftName is String ? giftName : '',
      giftId: giftId is String && giftId.isNotEmpty ? giftId : null,
      imageUrl: imageUrl is String && imageUrl.isNotEmpty ? imageUrl : null,
      strength: d(json['strength'], 1.0, 0.5, 2.0),
      seconds: n(json['seconds'], 0, 120),
      cooldown: n(json['cooldown'], 0, 600),
      repeat: repeat is String && skyRepeatRules.containsKey(repeat) ? repeat : 'extend',
      likesEvery: json['likesEvery'] is num ? n(json['likesEvery'], 1, 1000000) : likesPerTrigger,
    );
  }
}

/// Настройки режима: включён ли, 10 карточек, профиль эффектов, клавиша
/// рестарта, «меньше вспышек».
class SkySettings {
  const SkySettings({
    this.modeActive = true,
    this.cards = const [],
    this.profile = 'balance',
    this.restartKey = 'R',
    this.reduceFlashes = false,
  });

  final bool modeActive;
  final List<SkyCard> cards;
  final String profile;
  final String restartKey;
  final bool reduceFlashes;

  /// Всегда 10 карточек в порядке каталога (недостающие — по умолчанию).
  static List<SkyCard> complete(List<SkyCard> cards) => [
        for (final a in skyActions) cards.where((c) => c.actionId == a.id).firstOrNull ?? SkyCard(actionId: a.id),
      ];

  static SkySettings defaults() => SkySettings(cards: complete(const []));

  SkyCard card(String actionId) =>
      cards.where((c) => c.actionId == actionId).firstOrNull ?? SkyCard(actionId: actionId);

  /// Карточка для подарка (включённая, с этим подарком) или `null`.
  SkyCard? cardFor(GiftEvent event) {
    for (final c in cards) {
      if (c.enabled && c.matches(event)) return c;
    }
    return null;
  }

  SkySettings copyWith({
    bool? modeActive,
    List<SkyCard>? cards,
    String? profile,
    String? restartKey,
    bool? reduceFlashes,
  }) =>
      SkySettings(
        modeActive: modeActive ?? this.modeActive,
        cards: cards ?? this.cards,
        profile: profile ?? this.profile,
        restartKey: restartKey ?? this.restartKey,
        reduceFlashes: reduceFlashes ?? this.reduceFlashes,
      );

  Map<String, Object?> toJson() => {
        'version': 1,
        'modeActive': modeActive,
        'profile': profile,
        'restartKey': restartKey,
        'reduceFlashes': reduceFlashes,
        'cards': [for (final c in cards) c.toJson()],
      };

  static SkySettings fromJson(Map<String, Object?>? j) {
    if (j == null) return defaults();
    final raw = j['cards'];
    final profile = j['profile'];
    final key = j['restartKey'];
    return SkySettings(
      modeActive: j['modeActive'] != false,
      cards: complete([
        if (raw is List)
          for (final item in raw)
            if (SkyCard.fromJson(item) case final SkyCard c) c,
      ]),
      profile: profile is String && skyProfiles.containsKey(profile) ? profile : 'balance',
      restartKey: key is String && skyRestartKeys.contains(key) ? key : 'R',
      reduceFlashes: j['reduceFlashes'] == true,
    );
  }
}

class SkySettingsRepository {
  SkySettingsRepository(this.store);

  static const fileName = 'sky.json';
  final JsonStore store;

  Future<SkySettings> load() async {
    try {
      return SkySettings.fromJson(await store.read(fileName));
    } catch (_) {
      return SkySettings.defaults();
    }
  }

  Future<void> save(SkySettings s) => store.write(fileName, s.toJson());
}

final skySettingsProvider = NotifierProvider<SkySettingsController, SkySettings>(SkySettingsController.new);

class SkySettingsController extends Notifier<SkySettings> {
  Future<void> _pending = Future<void>.value();
  bool _touched = false;
  bool _disposed = false;

  @override
  SkySettings build() {
    ref.onDispose(() => _disposed = true);
    // Загружается сам при первом обращении; изменения до загрузки не теряются.
    unawaited(SkySettingsRepository(ref.read(jsonStoreProvider)).load().then((s) {
      if (!_touched && !_disposed) state = s;
    }).catchError((Object _) {}));
    return SkySettings.defaults();
  }

  Future<void> change(SkySettings Function(SkySettings s) f) {
    _touched = true;
    state = f(state);
    final repo = SkySettingsRepository(ref.read(jsonStoreProvider));
    final snapshot = state;
    _pending = _pending.then((_) => repo.save(snapshot)).catchError((Object _) {});
    return _pending;
  }

  Future<void> updateCard(SkyCard card) => change((s) => s.copyWith(cards: [
        for (final c in s.cards) c.actionId == card.actionId ? card : c,
      ]));

  Future<void> setModeActive(bool v) => change((s) => s.copyWith(modeActive: v));
  Future<void> setProfile(String v) => change((s) => s.copyWith(profile: v));
  Future<void> setRestartKey(String v) => change((s) => s.copyWith(restartKey: v));
  Future<void> setReduceFlashes(bool v) => change((s) => s.copyWith(reduceFlashes: v));
}
