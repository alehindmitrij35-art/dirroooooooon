import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/events/event_source.dart';
import '../../core/events/gift_event.dart';
import '../../core/events/stream_events.dart';
import '../../core/providers.dart';
import '../events/event_log.dart';
import '../minecraft/link_protocol.dart';
import '../minecraft/link_state.dart';
import '../minecraft/minecraft_link.dart';
import '../parkour/parkour_engine.dart' show ViewerActionEvent;
import 'sky_catalog.dart';
import 'sky_settings.dart';

/// Запись журнала действий: что, от кого, что ответил мод и почему.
class SkyJournalEntry {
  const SkyJournalEntry({
    required this.at,
    required this.actionId,
    required this.viewer,
    required this.state,
    required this.reason,
    this.test = false,
  });

  final DateTime at;
  final String actionId;
  final String viewer;

  /// sent, accepted, started, finished, deferred, rejected.
  final String state;
  final String reason;
  final bool test;

  String get title => skyActionById(actionId)?.title ?? actionId;
}

final skyJournalProvider = NotifierProvider<SkyJournal, List<SkyJournalEntry>>(SkyJournal.new);

class SkyJournal extends Notifier<List<SkyJournalEntry>> {
  static const limit = 120;

  @override
  List<SkyJournalEntry> build() => const [];

  void add(SkyJournalEntry e) {
    final next = [e, ...state];
    state = next.length > limit ? next.sublist(0, limit) : next;
  }

  void clear() => state = const [];
}

final skyEngineProvider = Provider<SkyEngine>((ref) {
  final engine = SkyEngine(ref);
  // Мир открыли или поменяли профиль — настройки сразу в мод.
  ref.listen<MinecraftLinkState>(minecraftLinkProvider, (prev, next) {
    if (next.worldReady && next.skyMode && !((prev?.worldReady ?? false) && (prev?.skyMode ?? false))) {
      engine.pushSettings();
    }
  });
  ref.listen<SkySettings>(skySettingsProvider, (prev, next) {
    if (prev == null ||
        prev.profile != next.profile ||
        prev.restartKey != next.restartKey ||
        prev.reduceFlashes != next.reduceFlashes) {
      engine.pushSettings();
    }
  });
  ref.onDispose(engine.dispose);
  return engine;
});

/// Срабатывания одной записи истории.
class _SkyTrack {
  _SkyTrack(this.recordId, this.card);

  final String recordId;
  final SkyCard? card;
  int sent = 0;
  bool announced = false;
  final Map<String, String> states = {};
  String lastReason = '';
}

/// Подарки → действия «Небесного разлома».
///
/// Одна штука подарка — одно событие с уникальным id (`запись#номер`):
/// мод выполняет каждое один раз, а повтор того же id получает прошлый
/// ответ. Ответы мода (принято / запущено / завершено / отложено /
/// отклонено) пишутся в запись истории и в журнал режима с причиной.
/// Работает, только когда открыт мир с трассой: в мире паркура подарки
/// обрабатывает паркур.
class SkyEngine {
  SkyEngine(this._ref) {
    final bus = _ref.read(eventBusProvider);
    _giftSubscription = bus.on<GiftEvent>().listen(_onGift);
    _likeSubscription = bus.on<LikeEvent>().listen(_onLike);
    _followSubscription = bus.on<FollowEvent>().listen(_onFollow);
    final link = _ref.read(minecraftLinkProvider.notifier);
    _ackSubscription = link.skyAcks.listen(_onAck);
    _resultSubscription = link.skyResults.listen(_onResult);
  }

  /// Больше срабатываний с одной серии не отправляем (очередь мода всё равно ограничена).
  static const maxPerRecord = 20;

  final Ref<Object?> _ref;
  late final StreamSubscription<GiftEvent> _giftSubscription;
  late final StreamSubscription<LikeEvent> _likeSubscription;
  late final StreamSubscription<FollowEvent> _followSubscription;
  late final StreamSubscription<ModSkyAck> _ackSubscription;
  late final StreamSubscription<ModSkyResult> _resultSubscription;
  final Map<String, _SkyTrack> _tracks = {};
  final Map<String, _SkyTrack> _byEvent = {};
  final Map<String, Completer<ModSkyResult?>> _commands = {};
  final Map<String, Completer<ModSkyAck?>> _tests = {};
  final Map<String, String> _eventAction = {};
  final Map<String, int> _likeRest = {};
  final Set<String> _followed = {};
  int _serial = 0;
  bool _disposed = false;

  EventLogController get _log => _ref.read(eventLogProvider.notifier);
  MinecraftLinkController get _link => _ref.read(minecraftLinkProvider.notifier);
  SkyJournal get _journal => _ref.read(skyJournalProvider.notifier);

  bool get _skyWorld => _ref.read(minecraftLinkProvider).skyReady;

  void dispose() {
    _disposed = true;
    unawaited(_giftSubscription.cancel());
    unawaited(_likeSubscription.cancel());
    unawaited(_followSubscription.cancel());
    unawaited(_ackSubscription.cancel());
    unawaited(_resultSubscription.cancel());
    for (final c in _commands.values) {
      if (!c.isCompleted) c.complete(null);
    }
    for (final c in _tests.values) {
      if (!c.isCompleted) c.complete(null);
    }
  }

  /// Профиль эффектов, клавиша рестарта, «меньше вспышек» — в мод.
  bool pushSettings() {
    final s = _ref.read(skySettingsProvider);
    return _link.sendSkySettings(profile: s.profile, restartKey: s.restartKey, reduceFlashes: s.reduceFlashes);
  }

  // ------------------------------------------------------------ команды

  /// Команда заезда. Ответ мода — текст для экрана.
  Future<(bool, String)> command(String cmd) async {
    final blocker = _ref.read(minecraftLinkProvider).skyBlocker;
    if (blocker != null) return (false, blocker);
    final id = 'cmd-${_serial++}-${DateTime.now().millisecondsSinceEpoch}';
    final waiter = Completer<ModSkyResult?>();
    _commands[id] = waiter;
    if (!_link.sendSkyCommand(id, cmd)) {
      _commands.remove(id);
      return (false, 'связь с игрой оборвалась');
    }
    final result = await waiter.future.timeout(const Duration(seconds: 4), onTimeout: () => null);
    _commands.remove(id);
    if (_disposed) return (false, 'Программа закрывается');
    if (result == null) return (false, 'игра не ответила');
    return (result.ok, result.text);
  }

  void _onResult(ModSkyResult r) {
    final waiter = _commands[r.id];
    if (waiter != null && !waiter.isCompleted) waiter.complete(r);
  }

  /// «Проверить»: действие карточки сразу в игре (без подарка, без перезарядки).
  Future<(bool, String)> test(SkyCard card) async {
    final blocker = _ref.read(minecraftLinkProvider).skyBlocker;
    if (blocker != null) return (false, blocker);
    final id = 'test-${_serial++}-${DateTime.now().millisecondsSinceEpoch}';
    final waiter = Completer<ModSkyAck?>();
    _tests[id] = waiter;
    _eventAction[id] = card.actionId;
    final sent = _send(id, card, viewer: 'Тест', label: 'Проверка', test: true);
    if (!sent) {
      _tests.remove(id);
      return (false, 'связь с игрой оборвалась');
    }
    _journal.add(SkyJournalEntry(
        at: DateTime.now(), actionId: card.actionId, viewer: 'Тест', state: 'sent', reason: '', test: true));
    final ack = await waiter.future.timeout(const Duration(seconds: 4), onTimeout: () => null);
    _tests.remove(id);
    if (_disposed) return (false, 'Программа закрывается');
    if (ack == null) return (false, 'игра не ответила');
    final text = '${_capital(skyAckLabel(ack.state))}${ack.reason.isEmpty ? '' : ': ${ack.reason}'}';
    return (ack.state == 'started' || ack.state == 'deferred', text);
  }

  static String _capital(String s) => s.isEmpty ? s : s[0].toUpperCase() + s.substring(1);

  bool _send(String id, SkyCard card, {required String viewer, required String label, required bool test}) =>
      _link.sendSkyAction(
        id: id,
        action: card.actionId,
        strength: card.strength,
        seconds: card.effectiveSeconds,
        cooldown: card.effectiveCooldown,
        repeat: card.repeat,
        viewerName: viewer,
        label: label,
        test: test,
      );

  // -------------------------------------------------------------- шина

  /// Лайки: у карточки «Лайки» свой порог — каждые N лайков зрителя дают одно срабатывание.
  void _onLike(LikeEvent e) {
    if (_disposed || !_skyWorld) return;
    final s = _ref.read(skySettingsProvider);
    if (!s.modeActive) return;
    for (final card in s.cards.where((c) => c.enabled && c.isLikes)) {
      final key = '${card.actionId}|${e.viewerId}';
      final every = card.likesEvery < 1 ? 1 : card.likesEvery;
      final total = (_likeRest[key] ?? 0) + e.likes;
      final n = total ~/ every;
      _likeRest[key] = total % every;
      if (n <= 0) continue;
      _publishSocial(e.source, e.viewerId, e.viewerName, e.viewerAvatar, card.socialTrigger, 'Лайки', n,
          'sky-likes:${card.actionId}:${e.sourceKey ?? generateEventId()}');
    }
  }

  /// Подписка: срабатывает один раз на зрителя за запуск программы.
  void _onFollow(FollowEvent e) {
    if (_disposed || !_skyWorld) return;
    final s = _ref.read(skySettingsProvider);
    if (!s.modeActive) return;
    for (final card in s.cards.where((c) => c.enabled && c.isFollow)) {
      if (!_followed.add('${card.actionId}|${e.viewerId}')) continue;
      _publishSocial(e.source, e.viewerId, e.viewerName, e.viewerAvatar, card.socialTrigger, 'Подписка', 1,
          'sky-follow:${card.actionId}:${e.viewerId}');
    }
  }

  void _publishSocial(EventSource source, String viewerId, String viewerName, String? avatar, String triggerId,
      String name, int count, String sourceKey) {
    _ref.read(eventBusProvider).publish(GiftEvent(
          id: generateEventId(),
          createdAt: _ref.read(clockProvider)(),
          source: source,
          viewerName: viewerName,
          viewerId: viewerId,
          viewerAvatar: avatar,
          giftName: name,
          giftId: triggerId,
          count: count,
          sourceKey: sourceKey,
        ));
  }

  void _onGift(GiftEvent step) {
    if (_disposed || !_skyWorld) return;
    final settings = _ref.read(skySettingsProvider);
    if (!settings.modeActive) return;
    final record = _ref.read(eventLogProvider).recordFor(step);
    if (record == null) return;
    var track = _tracks[record.id];
    if (track == null) {
      if (_tracks.length > 3000) _tracks.remove(_tracks.keys.first);
      track = _SkyTrack(record.id, settings.cardFor(record));
      _tracks[record.id] = track;
    }
    final card = track.card;
    if (card == null) return;
    final total = (record.count < 1 ? 1 : record.count).clamp(1, maxPerRecord).toInt();
    if (total <= track.sent) return; // повтор шага серии — ничего нового
    var failed = false;
    while (track.sent < total) {
      track.sent++;
      final id = '${record.id}#${track.sent}';
      _byEvent[id] = track;
      _eventAction[id] = card.actionId;
      track.states[id] = 'sent';
      if (!_send(id, card, viewer: record.viewerName, label: record.giftName, test: record.source == EventSource.test)) {
        track.states[id] = 'rejected';
        failed = true;
      }
    }
    if (_byEvent.length > 6000) _byEvent.remove(_byEvent.keys.first);
    if (failed) {
      track.lastReason = 'связь с игрой оборвалась';
    }
    _summarize(track, record);
  }

  void _onAck(ModSkyAck ack) {
    if (_disposed) return;
    final actionId = _eventAction[ack.id] ?? ack.action;
    final test = _tests[ack.id];
    if (test != null) {
      if (ack.state != 'accepted' && !test.isCompleted) test.complete(ack);
      _journal.add(SkyJournalEntry(
          at: DateTime.now(), actionId: actionId, viewer: 'Тест', state: ack.state, reason: ack.reason, test: true));
      return;
    }
    final track = _byEvent[ack.id];
    if (track == null) {
      // Ответ на проверку, которая уже закончилась ожиданием, — только в журнал.
      if (ack.id.startsWith('test-')) {
        _journal.add(SkyJournalEntry(
            at: DateTime.now(), actionId: actionId, viewer: 'Тест', state: ack.state, reason: ack.reason, test: true));
      }
      return;
    }
    track.states[ack.id] = ack.state;
    if (ack.reason.isNotEmpty) track.lastReason = ack.reason;
    final record = _ref.read(eventLogProvider).byId(track.recordId);
    _journal.add(SkyJournalEntry(
      at: DateTime.now(),
      actionId: actionId,
      viewer: record?.viewerName ?? '',
      state: ack.state,
      reason: ack.reason,
      test: record?.source == EventSource.test,
    ));
    if (record == null) return;
    _summarize(track, record);
    if (ack.state == 'started' && !track.announced) {
      track.announced = true;
      final card = track.card!;
      _ref.read(eventBusProvider).publish(ViewerActionEvent(
            viewerName: record.viewerName,
            giftName: record.giftName,
            actionId: 'sky:${card.actionId}',
            actionTitle: card.action.title,
            result: ack.reason.isEmpty ? card.action.title : ack.reason,
            ok: true,
            test: record.source == EventSource.test,
          ));
    }
  }

  /// Итог записи истории по ответам мода на все её срабатывания.
  void _summarize(_SkyTrack track, GiftEvent record) {
    final card = track.card;
    if (card == null) return;
    var started = 0, finished = 0, deferred = 0, rejected = 0, waiting = 0;
    for (final s in track.states.values) {
      switch (s) {
        case 'started':
          started++;
        case 'finished':
          finished++;
        case 'deferred':
          deferred++;
        case 'rejected':
          rejected++;
        default:
          waiting++;
      }
    }
    final parts = <String>[
      if (started > 0) 'идёт $started',
      if (finished > 0) 'завершено $finished',
      if (deferred > 0) 'в очереди $deferred',
      if (rejected > 0) 'отклонено $rejected',
      if (waiting > 0) 'отправлено $waiting',
    ];
    final reason = track.lastReason.isEmpty ? '' : ' · ${track.lastReason}';
    final ActionState state;
    if (started + finished > 0) {
      state = deferred + waiting > 0 ? ActionState.pending : ActionState.done;
    } else if (deferred + waiting > 0) {
      state = ActionState.pending;
    } else {
      state = ActionState.failed;
    }
    _log.setAction(record.id,
        actionState: state, title: card.action.title, result: 'Небесный разлом: ${parts.join(', ')}$reason');
  }
}
