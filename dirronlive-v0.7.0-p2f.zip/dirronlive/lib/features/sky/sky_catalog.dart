/// Действия зрителей в режиме «Небесный разлом»: 3 дешёвых, 3 средних,
/// 4 дорогих. Мод знает их по [SkyActionInfo.id]; длительность и
/// перезарядка по умолчанию совпадают с модом.
enum SkyTier {
  cheap('Дешёвые', 'дешёвое'),
  medium('Средние', 'среднее'),
  expensive('Дорогие', 'дорогое');

  const SkyTier(this.title, this.label);

  final String title;
  final String label;
}

class SkyActionInfo {
  const SkyActionInfo({
    required this.id,
    required this.title,
    required this.tier,
    required this.description,
    required this.movement,
    required this.seconds,
    required this.cooldown,
    this.help = false,
  });

  final String id;
  final String title;
  final SkyTier tier;
  final String description;

  /// Эффект движения (одновременно не больше двух).
  final bool movement;

  /// Длительность и перезарядка по умолчанию, секунды.
  final int seconds;
  final int cooldown;

  /// Помогает игроку, а не мешает.
  final bool help;
}

const skyActions = <SkyActionInfo>[
  SkyActionInfo(
    id: 'crosswind',
    title: 'Боковой ветер',
    tier: SkyTier.cheap,
    movement: true,
    seconds: 5,
    cooldown: 8,
    description: 'Сносит в сторону поперёк полёта',
  ),
  SkyActionInfo(
    id: 'heavy_wings',
    title: 'Тяжёлые крылья',
    tier: SkyTier.cheap,
    movement: true,
    seconds: 6,
    cooldown: 8,
    description: 'Элитры тянут вниз — труднее держать высоту',
  ),
  SkyActionInfo(
    id: 'tailwind',
    title: 'Попутный поток',
    tier: SkyTier.cheap,
    movement: true,
    seconds: 5,
    cooldown: 8,
    help: true,
    description: 'Подталкивает вперёд и чуть поднимает предел скорости',
  ),
  SkyActionInfo(
    id: 'turbulence',
    title: 'Турбулентность',
    tier: SkyTier.medium,
    movement: true,
    seconds: 6,
    cooldown: 15,
    description: 'Трясёт во все стороны',
  ),
  SkyActionInfo(
    id: 'narrow',
    title: 'Узкий проход',
    tier: SkyTier.medium,
    movement: false,
    seconds: 12,
    cooldown: 20,
    description: 'Кольца сужаются — попасть труднее',
  ),
  SkyActionInfo(
    id: 'air_brake',
    title: 'Воздушный тормоз',
    tier: SkyTier.medium,
    movement: true,
    seconds: 4,
    cooldown: 15,
    description: 'Резко сбрасывает скорость',
  ),
  SkyActionInfo(
    id: 'storm',
    title: 'Грозовой фронт',
    tier: SkyTier.expensive,
    movement: true,
    seconds: 8,
    cooldown: 40,
    description: 'Порывы ветра с разных сторон и молнии рядом',
  ),
  SkyActionInfo(
    id: 'time_rift',
    title: 'Временной разлом',
    tier: SkyTier.expensive,
    movement: false,
    seconds: 2,
    cooldown: 45,
    description: 'Отматывает полёт на несколько секунд назад',
  ),
  SkyActionInfo(
    id: 'slalom',
    title: 'Небесный слалом',
    tier: SkyTier.expensive,
    movement: false,
    seconds: 15,
    cooldown: 45,
    description: 'Трое ворот влево-вправо перед кольцом; мимо ворот — ошибка',
  ),
  SkyActionInfo(
    id: 'guardian',
    title: 'Ангел-хранитель',
    tier: SkyTier.expensive,
    movement: false,
    seconds: 30,
    cooldown: 60,
    help: true,
    description: 'Следующая ошибка не засчитывается',
  ),
];

SkyActionInfo? skyActionById(String id) {
  for (final a in skyActions) {
    if (a.id == id) return a;
  }
  return null;
}

/// Повтор подарка, пока эффект ещё идёт.
const skyRepeatRules = <String, String>{
  'extend': 'Продлить',
  'queue': 'В очередь',
  'ignore': 'Отклонить',
};

/// Профили эффектов: лимит частиц 80 / 160 / 300.
const skyProfiles = <String, String>{
  'performance': 'Производительность',
  'balance': 'Баланс',
  'beauty': 'Красота',
};

const skyProfileParticles = <String, int>{'performance': 80, 'balance': 160, 'beauty': 300};

/// Клавиша быстрого рестарта в игре.
const skyRestartKeys = <String>['R', 'G', 'H', 'J', 'K', 'B', 'N', 'F6', 'F7', 'F8', 'F9', 'NONE'];

String skyKeyLabel(String key) => key == 'NONE' ? 'Выключена' : key;

/// Ответ мода по-русски.
String skyAckLabel(String state) => switch (state) {
      'accepted' => 'принято',
      'started' => 'запущено',
      'finished' => 'завершено',
      'deferred' => 'отложено',
      'rejected' => 'отклонено',
      'sent' => 'отправлено',
      _ => state,
    };

/// Фаза заезда по-русски.
String skyPhaseLabel(String phase) => switch (phase) {
      'idle' => 'Не начат',
      'countdown' => 'Отсчёт',
      'running' => 'В полёте',
      'paused' => 'Пауза',
      'resuming' => 'Продолжение…',
      'finished' => 'Финиш',
      _ => phase,
    };

/// Состояние карты по-русски.
String skyMapLabel(String map) => switch (map) {
      'ready' => 'готова',
      'preparing' => 'подготовка',
      _ => 'отсутствует',
    };

/// «1:23.4»
String skyClock(int ms) {
  final t = ms < 0 ? 0 : ms;
  final m = t ~/ 60000;
  final s = (t ~/ 1000) % 60;
  final d = (t ~/ 100) % 10;
  return '$m:${s.toString().padLeft(2, '0')}.$d';
}
