import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../core/storage/json_store.dart';

/// Кого показывать в чате Minecraft и кого озвучивать (можно несколько сразу).
enum ChatWho {
  all('all', 'Всех'),
  followers('followers', 'Подписчиков'),
  fans('fans', 'Фан-клуб'),
  subscribers('subscribers', 'Платная подписка'),
  moderators('moderators', 'Модераторов'),
  gifters('gifters', 'Кто дарил подарки'),
  listed('listed', 'Из списка');

  const ChatWho(this.id, this.label);
  final String id;
  final String label;

  static ChatWho? fromId(Object? id) {
    for (final w in values) {
      if (w.id == id) return w;
    }
    return null;
  }

  /// Из сохранённого: список id или (старый формат) одна строка.
  static Set<ChatWho> parse(Object? raw) {
    final ids = raw is List ? raw : [raw];
    final set = ids.map(fromId).whereType<ChatWho>().toSet();
    return set.isEmpty ? {ChatWho.all} : set;
  }
}

/// Кто пишет в чат: для отбора по статусу.
class ChatViewer {
  const ChatViewer({
    required this.id,
    required this.name,
    this.follower = false,
    this.fan = false,
    this.subscriber = false,
    this.moderator = false,
  });

  final String id;
  final String name;
  final bool follower;
  final bool fan;
  final bool subscriber;
  final bool moderator;
}

/// Голоса озвучки. Нейроголоса Microsoft (как в Edge) — живые и выразительные,
/// нужен интернет; «Голос Windows» работает без интернета.
const chatVoices = <String, String>{
  'mix': 'Разные голоса (у каждого зрителя свой)',
  'ru-RU-SvetlanaNeural': 'Светлана (нейроголос)',
  'ru-RU-DmitryNeural': 'Дмитрий (нейроголос)',
  'windows': 'Голос Windows (без интернета)',
};

class ChatSettings {
  const ChatSettings({
    this.minecraft = true,
    this.minecraftWho = const {ChatWho.all},
    this.voice = false,
    this.voiceWho = const {ChatWho.all},
    this.allow = const [],
    this.block = const [],
    this.voiceName = 'mix',
    this.rate = 10,
    this.volume = 90,
    this.readNames = true,
    this.expressive = true,
    this.skipLinks = true,
    this.maxLength = 150,
    this.maxDelay = 15,
  });

  /// Сообщения чата TikTok — в чат Minecraft.
  final bool minecraft;
  final Set<ChatWho> minecraftWho;

  /// Озвучка чата.
  final bool voice;
  final Set<ChatWho> voiceWho;

  /// Ники, которых озвучивать всегда (и для режима «Только из списка»).
  final List<String> allow;

  /// Ники, которых не озвучивать и не показывать никогда.
  final List<String> block;
  final String voiceName;

  /// Скорость речи, % (−50…+100).
  final int rate;

  /// Громкость, % (0…100).
  final int volume;
  final bool readNames;

  /// Интонация по сообщению: «!» — бодрее, «?» — вопросом, КАПС — громче, смех — весело.
  final bool expressive;
  final bool skipLinks;

  /// Длинные сообщения обрезаются до стольких символов.
  final int maxLength;

  /// Сообщение ждёт очереди дольше стольких секунд — его не озвучивать
  /// (озвучка не отстаёт от чата). 0 — озвучивать всё.
  final int maxDelay;

  ChatSettings copyWith({
    bool? minecraft,
    Set<ChatWho>? minecraftWho,
    bool? voice,
    Set<ChatWho>? voiceWho,
    List<String>? allow,
    List<String>? block,
    String? voiceName,
    int? rate,
    int? volume,
    bool? readNames,
    bool? expressive,
    bool? skipLinks,
    int? maxLength,
    int? maxDelay,
  }) =>
      ChatSettings(
        minecraft: minecraft ?? this.minecraft,
        minecraftWho: minecraftWho ?? this.minecraftWho,
        voice: voice ?? this.voice,
        voiceWho: voiceWho ?? this.voiceWho,
        allow: allow ?? this.allow,
        block: block ?? this.block,
        voiceName: voiceName ?? this.voiceName,
        rate: rate ?? this.rate,
        volume: volume ?? this.volume,
        readNames: readNames ?? this.readNames,
        expressive: expressive ?? this.expressive,
        skipLinks: skipLinks ?? this.skipLinks,
        maxLength: maxLength ?? this.maxLength,
        maxDelay: maxDelay ?? this.maxDelay,
      );

  Map<String, Object?> toJson() => {
        'version': 1,
        'minecraft': minecraft,
        'minecraftWho': [for (final w in minecraftWho) w.id],
        'voice': voice,
        'voiceWho': [for (final w in voiceWho) w.id],
        'allow': allow,
        'block': block,
        'voiceName': voiceName,
        'rate': rate,
        'volume': volume,
        'readNames': readNames,
        'expressive': expressive,
        'skipLinks': skipLinks,
        'maxLength': maxLength,
        'maxDelay': maxDelay,
      };

  static ChatSettings fromJson(Map<String, Object?>? j) {
    if (j == null) return const ChatSettings();
    List<String> names(Object? v) => v is List ? normalizeNames(v.whereType<String>().join(',')) : const [];
    int number(Object? v, int fallback, int min, int max) =>
        v is num ? v.toInt().clamp(min, max).toInt() : fallback;
    final voiceName = j['voiceName'];
    return ChatSettings(
      minecraft: j['minecraft'] != false,
      minecraftWho: ChatWho.parse(j['minecraftWho']),
      voice: j['voice'] == true,
      voiceWho: ChatWho.parse(j['voiceWho']),
      allow: names(j['allow']),
      block: names(j['block']),
      voiceName: voiceName is String && chatVoices.containsKey(voiceName) ? voiceName : 'mix',
      rate: number(j['rate'], 10, -50, 100),
      volume: number(j['volume'], 90, 0, 100),
      readNames: j['readNames'] != false,
      expressive: j['expressive'] != false,
      skipLinks: j['skipLinks'] != false,
      maxLength: number(j['maxLength'], 150, 20, 300),
      maxDelay: number(j['maxDelay'], 15, 0, 120),
    );
  }

  /// «@Mira, alex ;Котик» → ['mira', 'alex', 'котик'].
  static List<String> normalizeNames(String text) => text
      .split(RegExp(r'[,;\n]+'))
      .map((s) => s.trim().replaceFirst(RegExp(r'^@'), '').toLowerCase())
      .where((s) => s.isNotEmpty)
      .toSet()
      .toList();

  static bool _inList(List<String> list, String viewerId, String viewerName) =>
      list.contains(viewerId.toLowerCase()) || list.contains(viewerName.toLowerCase());

  /// Проходит ли зритель отбор [who]: подходит под любую из отмеченных групп.
  /// «Никогда» сильнее всего, «Всегда» — сильнее отбора.
  bool passes(Set<ChatWho> who, ChatViewer v, Set<String> gifters) {
    if (_inList(block, v.id, v.name)) return false;
    if (_inList(allow, v.id, v.name)) return true;
    for (final w in who) {
      final ok = switch (w) {
        ChatWho.all => true,
        ChatWho.followers => v.follower,
        ChatWho.fans => v.fan,
        ChatWho.subscribers => v.subscriber,
        ChatWho.moderators => v.moderator,
        ChatWho.gifters => gifters.contains(v.id) || gifters.contains(v.name.toLowerCase()),
        ChatWho.listed => false,
      };
      if (ok) return true;
    }
    return false;
  }
}

class ChatSettingsRepository {
  ChatSettingsRepository(this.store);

  static const fileName = 'chat.json';
  final JsonStore store;

  Future<ChatSettings> load() async {
    try {
      return ChatSettings.fromJson(await store.read(fileName));
    } catch (_) {
      return const ChatSettings();
    }
  }

  Future<void> save(ChatSettings s) => store.write(fileName, s.toJson());
}

final chatSettingsProvider = NotifierProvider<ChatSettingsController, ChatSettings>(ChatSettingsController.new);

class ChatSettingsController extends Notifier<ChatSettings> {
  Future<void> _pending = Future<void>.value();
  bool _touched = false;

  bool _disposed = false;

  @override
  ChatSettings build() {
    ref.onDispose(() => _disposed = true);
    // Загружается сам при первом обращении; изменения до загрузки не теряются.
    unawaited(ChatSettingsRepository(ref.read(jsonStoreProvider)).load().then((s) {
      if (!_touched && !_disposed) state = s;
    }).catchError((Object _) {}));
    return const ChatSettings();
  }

  Future<void> change(ChatSettings Function(ChatSettings s) f) {
    _touched = true;
    state = f(state);
    final repo = ChatSettingsRepository(ref.read(jsonStoreProvider));
    final snapshot = state;
    _pending = _pending.then((_) => repo.save(snapshot)).catchError((Object _) {});
    return _pending;
  }
}
