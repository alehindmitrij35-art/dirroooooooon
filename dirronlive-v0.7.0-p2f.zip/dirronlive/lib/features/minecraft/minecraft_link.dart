import 'dart:async';
import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/events/gift_event.dart';
import '../settings/settings_controller.dart';
import 'link_protocol.dart';
import 'link_state.dart';

class MinecraftLinkConfig {
  const MinecraftLinkConfig({
    this.port = LinkProtocol.defaultPort,
    this.ackTimeout = const Duration(seconds: 5),
    this.pingInterval = const Duration(seconds: 5),
  });

  /// 8765 в программе; в тестах 0 — любой свободный порт.
  final int port;

  /// Сколько ждать подтверждения от мода.
  final Duration ackTimeout;

  /// Как часто проверять, что мод ещё на связи.
  final Duration pingInterval;
}

final minecraftLinkConfigProvider =
    Provider<MinecraftLinkConfig>((ref) => const MinecraftLinkConfig());

final minecraftLinkProvider =
    NotifierProvider<MinecraftLinkController, MinecraftLinkState>(
        MinecraftLinkController.new);

/// Локальный WebSocket-сервер на 127.0.0.1, к которому подключается мод.
///
/// Только локальный адрес: снаружи ноутбука к серверу подключиться нельзя.
/// Одновременно обслуживается один мод; новое подключение заменяет старое
/// (например, после перезапуска игры).
class MinecraftLinkController extends Notifier<MinecraftLinkState> {
  HttpServer? _server;
  StreamSubscription<HttpRequest>? _serverSubscription;
  WebSocket? _mod;
  int _generation = 0;
  bool _disposed = false;
  final StreamController<String> _acks = StreamController<String>.broadcast();
  final StreamController<ModActionResult> _actionResults =
      StreamController<ModActionResult>.broadcast();

  /// Ответы мода на действия паркура.
  Stream<ModActionResult> get actionResults => _actionResults.stream;

  final StreamController<ModSkyAck> _skyAcks = StreamController<ModSkyAck>.broadcast();
  final StreamController<ModSkyResult> _skyResults = StreamController<ModSkyResult>.broadcast();

  /// «Небесный разлом»: ответы на действия зрителей и на команды заезда.
  Stream<ModSkyAck> get skyAcks => _skyAcks.stream;
  Stream<ModSkyResult> get skyResults => _skyResults.stream;

  /// ID подарков, которые мод подтвердил (показал в игре).
  Stream<String> get acknowledgements => _acks.stream;

  MinecraftLinkConfig get _config => ref.read(minecraftLinkConfigProvider);

  @override
  MinecraftLinkState build() {
    ref.onDispose(() {
      _disposed = true;
      _generation++;
      unawaited(_shutdown());
      unawaited(_acks.close());
      unawaited(_actionResults.close());
      unawaited(_skyAcks.close());
      unawaited(_skyResults.close());
    });
    return const MinecraftLinkState();
  }

  /// Запускает сервер. Повторный вызов при работающей связи ничего не делает.
  Future<void> start() async {
    if (_disposed) return;
    if (state.phase != LinkPhase.off && state.phase != LinkPhase.error) return;
    final generation = ++_generation;
    final port = _config.port;
    state = MinecraftLinkState(phase: LinkPhase.starting, port: port);
    try {
      final server =
          await HttpServer.bind(InternetAddress.loopbackIPv4, port, shared: false);
      if (_disposed || generation != _generation) {
        await server.close(force: true);
        return;
      }
      _server = server;
      _serverSubscription = server.listen(_onRequest, onError: (Object _) {});
      state = MinecraftLinkState(
          phase: LinkPhase.waitingForMod, port: server.port);
    } on SocketException catch (e) {
      if (_disposed || generation != _generation) return;
      final busy = _isAddressInUse(e);
      state = MinecraftLinkState(
        phase: LinkPhase.error,
        port: port,
        errorTitle: busy ? 'Порт $port занят' : 'Не удалось запустить связь',
        errorMessage: busy
            ? 'Порт $port уже занят другой программой — возможно, открыт второй '
                'Dirronlive. Закройте её и нажмите «Повторить».'
            : 'Не удалось открыть порт $port: ${_reason(e)}. '
                'Нажмите «Повторить».',
      );
    }
  }

  /// Повторная попытка после ошибки.
  Future<void> retry() async {
    if (state.phase != LinkPhase.error) return;
    await start();
  }

  /// Выключает связь: отключает мод и освобождает порт.
  Future<void> stop() async {
    _generation++;
    await _shutdown();
    if (!_disposed) state = const MinecraftLinkState();
  }

  /// Отправляет подарок моду. `false`, если мир не готов или связь оборвалась.
  bool sendGift({
    required String deliveryId,
    required GiftEvent record,
    required int units,
    int? comboTotal,
  }) {
    final mod = _mod;
    if (mod == null || !state.worldReady) return false;
    try {
      mod.add(LinkProtocol.gift(
        deliveryId: deliveryId,
        record: record,
        units: units,
        comboTotal: comboTotal,
      ));
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Действие паркура. `false`, если отправить не удалось.
  bool sendAction({
    required String id,
    required String action,
    required Map<String, Object?> params,
    required String label,
    required String viewerName,
    required bool test,
    int total = 1,
  }) =>
      _send(LinkProtocol.action(
        id: id,
        action: action,
        params: params,
        label: label,
        viewerName: viewerName,
        test: test,
        total: total,
      ));

  /// «Небесный разлом»: команда заезда. `false`, если отправить не удалось.
  bool sendSkyCommand(String id, String cmd) => _send(LinkProtocol.skyCommand(id, cmd));

  bool sendSkySettings({required String profile, required String restartKey, required bool reduceFlashes}) =>
      _send(LinkProtocol.skySettings(profile: profile, restartKey: restartKey, reduceFlashes: reduceFlashes));

  bool sendSkyAction({
    required String id,
    required String action,
    required double strength,
    required int seconds,
    required int cooldown,
    required String repeat,
    required String viewerName,
    required String label,
    required bool test,
  }) =>
      _send(LinkProtocol.skyAction(
        id: id,
        action: action,
        strength: strength,
        seconds: seconds,
        cooldown: cooldown,
        repeat: repeat,
        viewerName: viewerName,
        label: label,
        test: test,
      ));

  /// Погода и время в мире (см. [LinkProtocol.world]).
  bool sendWorld({String? time, String? weather, bool? freeze}) =>
      _send(LinkProtocol.world(time: time, weather: weather, freeze: freeze));

  /// Сообщение чата TikTok — в чат Minecraft («[TikTok] Mira: привет»).
  bool sendChat(String name, String text, String color) => _send(LinkProtocol.chat(name, text, color));

  /// Обратный отсчёт в игре; [seconds] = 0 — отменить с надписью [title].
  bool sendCountdown(String id, String title, int seconds) => _send(seconds > 0
      ? LinkProtocol.countdown(id, title, seconds)
      : LinkProtocol.countdownCancel(id, title));

  bool _send(String message) {
    final mod = _mod;
    if (mod == null || !state.worldReady) return false;
    try {
      mod.add(message);
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> _onRequest(HttpRequest request) async {
    final path = request.uri.path;
    if (path != '/' && path != '/dirronlive') {
      request.response.statusCode = HttpStatus.notFound;
      await request.response.close();
      return;
    }
    if (!WebSocketTransformer.isUpgradeRequest(request)) {
      request.response
        ..statusCode = HttpStatus.upgradeRequired
        ..write('Dirronlive: здесь ждёт подключения мод Dirronlive Bridge.');
      await request.response.close();
      return;
    }

    final generation = _generation;
    final WebSocket socket;
    try {
      socket = await WebSocketTransformer.upgrade(request);
    } catch (_) {
      return;
    }
    if (_disposed || generation != _generation || _server == null) {
      unawaited(socket.close());
      return;
    }

    final previous = _mod;
    _mod = socket;
    if (previous != null) unawaited(previous.close());

    socket.pingInterval = _config.pingInterval;
    state = MinecraftLinkState(phase: LinkPhase.modConnected, port: state.port);
    socket.listen(
      (data) => _onMessage(socket, data),
      onDone: () => _onModGone(socket),
      onError: (Object _) => _onModGone(socket),
      cancelOnError: true,
    );
    socket.add(LinkProtocol.welcome());
  }

  void _onMessage(WebSocket socket, Object? data) {
    if (_disposed || !identical(socket, _mod)) return;
    final message = LinkProtocol.parse(data);
    switch (message) {
      case ModHello(
          :final worldReady,
          :final modVersion,
          :final minecraftVersion,
          :final parkourActions,
          :final actionQueue,
          :final sky,
        ):
        state = state.copyWith(
          phase: worldReady ? LinkPhase.worldReady : LinkPhase.modConnected,
          modVersion: modVersion,
          minecraftVersion: minecraftVersion,
          parkourActions: parkourActions,
          actionQueue: actionQueue,
          skyMode: sky,
        );
      case ModWorld(:final worldReady):
        state = state.copyWith(
          phase: worldReady ? LinkPhase.worldReady : LinkPhase.modConnected,
          parkour: worldReady ? null : ParkourInfo.none,
          sky: worldReady ? null : SkyInfo.none,
        );
      case ModSky(:final info):
        state = state.copyWith(sky: info);
      case final ModSkyAck ack:
        _skyAcks.add(ack);
      case final ModSkyResult result:
        _skyResults.add(result);
      case ModParkour(:final info):
        state = state.copyWith(parkour: info);
      case final ModActionResult result:
        _actionResults.add(result);
      case ModAck(:final id):
        _acks.add(id);
      case null:
        break;
    }
  }

  void _onModGone(WebSocket socket) {
    if (_disposed || !identical(socket, _mod)) return;
    _mod = null;
    if (_server != null) {
      state = MinecraftLinkState(phase: LinkPhase.waitingForMod, port: state.port);
    }
  }

  Future<void> _shutdown() async {
    final mod = _mod;
    final server = _server;
    final subscription = _serverSubscription;
    _mod = null;
    _server = null;
    _serverSubscription = null;
    if (mod != null) unawaited(mod.close().catchError((Object _) {}));
    await subscription?.cancel();
    try {
      await server?.close(force: true);
    } catch (_) {
      // Порт уже освобождён.
    }
  }

  static bool _isAddressInUse(SocketException e) {
    const codes = {98, 48, 10048}; // Linux, macOS, Windows (WSAEADDRINUSE)
    final code = e.osError?.errorCode;
    if (code != null && codes.contains(code)) return true;
    final text = '${e.message} ${e.osError?.message ?? ''}'.toLowerCase();
    return text.contains('in use') ||
        text.contains('shared flag') ||
        text.contains('используется');
  }

  static String _reason(SocketException e) {
    final os = e.osError?.message.trim();
    if (os != null && os.isNotEmpty) return os;
    return e.message;
  }
}

/// Включение и выключение связи из интерфейса: меняет сервер и запоминает
/// выбор в настройках, чтобы при следующем запуске связь поднялась сама.
final minecraftLinkSwitchProvider =
    Provider<MinecraftLinkSwitch>((ref) => MinecraftLinkSwitch(ref));

class MinecraftLinkSwitch {
  MinecraftLinkSwitch(this._ref);

  final Ref<Object?> _ref;

  /// Возвращает текст ошибки сохранения настроек или `null`.
  Future<String?> setEnabled(bool enabled) async {
    final link = _ref.read(minecraftLinkProvider.notifier);
    if (enabled) {
      await link.start();
    } else {
      await link.stop();
    }
    return _ref.read(settingsProvider.notifier).setMinecraftLinkEnabled(enabled);
  }
}
