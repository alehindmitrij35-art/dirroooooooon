import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../minecraft/minecraft_link.dart';
import '../parkour/gift_catalog.dart';
import '../parkour/parkour_rules.dart';
import 'overlay_kind.dart';
import 'overlay_models.dart';
import 'overlay_settings.dart';
import 'stream_stats.dart';

/// Имена, которые всегда указывают на этот компьютер (127.0.0.1).
/// TikTok LIVE Studio не принимает в поле «Ссылка» ни localhost, ни IP-адрес —
/// нужен домен с точкой, поэтому для него ссылка идёт через такое имя.
const overlayHosts = ['localtest.me', 'lvh.me'];

class OverlayServerState {
  const OverlayServerState({
    this.port,
    this.error,
    this.starting = false,
    this.host = 'localtest.me',
    this.hostOk,
    this.hostProblem,
  });

  final int? port;
  final String? error;
  final bool starting;

  /// Имя для ссылок TikTok LIVE Studio.
  final String host;

  /// null — ещё проверяем; true — ссылка открывается; false — см. [hostProblem].
  final bool? hostOk;
  final String? hostProblem;

  bool get running => port != null;

  /// Ссылка для TikTok LIVE Studio (Добавить источник → Ссылка).
  String linkFor(OverlayKind kind) => 'http://$host:${port ?? 8777}/overlay/${kind.slug}';

  /// Ссылка для OBS и браузера на этом компьютере.
  String localLinkFor(OverlayKind kind) => 'http://127.0.0.1:${port ?? 8777}/overlay/${kind.slug}';

  OverlayServerState withHost(String host, bool ok, String? problem) => OverlayServerState(
        port: port,
        error: error,
        starting: starting,
        host: host,
        hostOk: ok,
        hostProblem: problem,
      );
}

/// Текущие данные для оверлеев (общие для сервера и предпросмотра).
final overlayInputsProvider = Provider<OverlayInputs>((ref) => OverlayInputs(
      settings: ref.watch(overlaySettingsProvider),
      stats: ref.watch(streamStatsProvider),
      link: ref.watch(minecraftLinkProvider),
      rules: ref.watch(parkourRulesProvider).rules,
      catalog: ref.watch(giftCatalogProvider).catalog,
      now: DateTime.now(),
    ));

final overlayServerProvider =
    NotifierProvider<OverlayServerController, OverlayServerState>(OverlayServerController.new);

/// Локальный сервер оверлеев: http://127.0.0.1:8777/overlay/<slug> —
/// страница с прозрачным фоном для TikTok LIVE Studio / OBS, сама
/// обновляется, добавлять заново в сцену не нужно.
class OverlayServerController extends Notifier<OverlayServerState> {
  HttpServer? _server;
  String? _template;

  @override
  OverlayServerState build() {
    ref.onDispose(() => unawaited(_server?.close(force: true)));
    return const OverlayServerState();
  }

  /// [checkHost] — проверить, что ссылка для TikTok LIVE Studio открывается.
  Future<void> start({int? port, String? template, bool checkHost = true}) async {
    if (_server != null) return;
    state = const OverlayServerState(starting: true);
    _template = template ?? await _loadTemplate();
    final wanted = port ?? ref.read(overlaySettingsProvider).port;
    try {
      final server = await HttpServer.bind(InternetAddress.loopbackIPv4, wanted);
      _server = server;
      state = OverlayServerState(port: server.port);
      server.listen(_handle, onError: (_) {});
      if (checkHost) unawaited(_checkHosts(server));
    } on SocketException catch (e) {
      state = OverlayServerState(
          error: 'Порт $wanted занят другой программой (${e.osError?.message ?? e.message}). '
              'Закройте её и нажмите «Повторить».');
    }
  }

  /// Находит имя, через которое страница реально открывается с этого
  /// компьютера: имя → 127.0.0.1 → наш сервер отвечает.
  Future<void> _checkHosts(HttpServer server) async {
    final reasons = <String>[];
    for (final host in overlayHosts) {
      final reason = await _tryHost(host, server.port);
      if (_server != server) return; // сервер уже перезапущен
      if (reason == null) {
        state = state.withHost(host, true, null);
        return;
      }
      reasons.add('$host: $reason');
    }
    if (_server != server) return;
    state = state.withHost(
      overlayHosts.first,
      false,
      'Ссылка для TikTok LIVE Studio не открывается (${reasons.join('; ')}). '
      'Обычно так бывает, когда роутер или антивирус не пускает имена, указывающие на ваш компьютер. '
      'Что сделать: отключите в роутере «защиту от DNS rebinding» или смените DNS на 1.1.1.1; '
      'либо добавьте оверлей в OBS по ссылке с 127.0.0.1 и передайте сцену в LIVE Studio через виртуальную камеру OBS.',
    );
  }

  static Future<String?> _tryHost(String host, int port) async {
    try {
      final addresses = await InternetAddress.lookup(host).timeout(const Duration(seconds: 5));
      if (!addresses.any((a) => a.isLoopback)) return 'указывает не на этот компьютер';
    } catch (_) {
      return 'имя не находится';
    }
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 4);
    try {
      final req = await client.getUrl(Uri.parse('http://$host:$port/api/overlay/goal'));
      final res = await req.close().timeout(const Duration(seconds: 4));
      await res.drain<void>();
      return res.statusCode == 200 ? null : 'ответ ${res.statusCode}';
    } catch (_) {
      return 'страница не открылась';
    } finally {
      client.close(force: true);
    }
  }

  Future<void> stop() async {
    final server = _server;
    _server = null;
    await server?.close(force: true);
    state = const OverlayServerState();
  }

  Future<void> retry() async {
    await stop();
    await start();
  }

  static Future<String> _loadTemplate() async {
    try {
      return await rootBundle.loadString('assets/overlay/overlay.html');
    } catch (_) {
      return '<!DOCTYPE html><html><body style="background:transparent;color:#fff">'
          '<script>/* {{SLUG}} {{TITLE}} */</script>Шаблон оверлея не найден</body></html>';
    }
  }

  /// JSON-модель оверлея (для страницы и тестов).
  Map<String, Object?> model(OverlayKind kind) => buildOverlayModel(kind, ref.read(overlayInputsProvider));

  Future<void> _handle(HttpRequest request) async {
    final res = request.response;
    res.headers
      ..set('Cache-Control', 'no-store')
      ..set('Access-Control-Allow-Origin', '*');
    final segments = request.uri.pathSegments;
    try {
      if (segments.length == 3 && segments[0] == 'api' && segments[1] == 'overlay') {
        final kind = OverlayKind.bySlug(segments[2]);
        if (kind == null) {
          await _notFound(res);
          return;
        }
        res.headers.contentType = ContentType('application', 'json', charset: 'utf-8');
        res.write(jsonEncode(model(kind)));
      } else if (segments.length == 2 && segments[0] == 'overlay') {
        final kind = OverlayKind.bySlug(segments[1]);
        if (kind == null) {
          await _notFound(res);
          return;
        }
        res.headers.contentType = ContentType.html;
        res.write((_template ?? '').replaceAll('{{SLUG}}', kind.slug).replaceAll('{{TITLE}}', kind.title));
      } else if (segments.isEmpty) {
        res.headers.contentType = ContentType.html;
        final links = OverlayKind.values
            .map((k) => '<li><a style="color:#A78BFA" href="/overlay/${k.slug}">${k.title}</a></li>')
            .join();
        res.write('<!DOCTYPE html><meta charset="utf-8"><body style="font-family:Segoe UI;background:#100D19;'
            'color:#F7F3FF"><h1>Оверлеи Dirronlive</h1><ul>$links</ul></body>');
      } else {
        await _notFound(res);
        return;
      }
    } catch (e) {
      res.statusCode = HttpStatus.internalServerError;
      res.write('error');
    }
    await res.close();
  }

  Future<void> _notFound(HttpResponse res) async {
    res.statusCode = HttpStatus.notFound;
    res.write('not found');
    await res.close();
  }
}
