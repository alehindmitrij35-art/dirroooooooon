package dev.dirronlive.sky.map;

import dev.dirronlive.parkour.map.Blueprint;
import dev.dirronlive.sky.core.Checkpoint;
import dev.dirronlive.sky.core.Ring;
import dev.dirronlive.sky.core.Sector;
import dev.dirronlive.sky.core.Track;
import dev.dirronlive.sky.core.V3;
import dev.dirronlive.sky.core.Zone;
import java.util.ArrayList;
import java.util.List;

/**
 * Карта «Небесные острова»: стартовый остров, 6 секторов по 6–8 колец по
 * большой спирали вниз (с восходящими потоками, чтобы хватало высоты),
 * парящие острова по темам секторов, финишный остров с разломом и
 * тренировочный круг за стартом.
 *
 * <p>Всё считается заранее и одинаково при каждой сборке: трасса — данные
 * (кольца рисует клиент), острова — обычные блоки готового мира. Ни один
 * блок не стоит ближе {@link #CLEARANCE} к линии полёта.
 */
public final class SkyIslands {
    private SkyIslands() {}

    public static final String ID = "sky_islands";
    public static final String NAME = "Небесные острова";
    public static final int VERSION = 1;
    /** Свободное место вокруг линии полёта сверх радиуса кольца. */
    public static final double CLEARANCE = 3.0;
    public static final int LOBBY_Y = 206;
    public static final int[] RINGS = {6, 7, 7, 7, 8, 8};
    /** Снижение между кольцами (≈ 1 : 7.5 — элитры держат скорость без фейерверков). */
    public static final double DESCENT = 4.2;
    /** Набор высоты в восходящем потоке. */
    public static final double LIFT_GAIN = 16;
    public static final String[] SECTOR_NAMES = {
            "Зелёные острова", "Цветущие сады", "Ледяные пики", "Аметистовые гроты", "Огненные скалы", "Разлом"};

    public record Layout(Track track, Blueprint blueprint, List<V3[]> path) {}

    /** Тема сектора: верх, слой под ним, сердцевина, акцент, ствол, листва, мелочи сверху. */
    record Palette(String top, String soil, String core, String accent, String log, String leaves, String[] small,
                   String light) {}

    static final Palette[] THEMES = {
            new Palette("minecraft:grass_block", "minecraft:dirt", "minecraft:stone", "minecraft:moss_block",
                    "minecraft:oak_log", "minecraft:oak_leaves[persistent=true]",
                    new String[] {"minecraft:poppy", "minecraft:dandelion", "minecraft:short_grass", "minecraft:cornflower"},
                    "minecraft:lantern"),
            new Palette("minecraft:grass_block", "minecraft:dirt", "minecraft:stone", "minecraft:pink_terracotta",
                    "minecraft:cherry_log", "minecraft:cherry_leaves[persistent=true]",
                    new String[] {"minecraft:pink_tulip", "minecraft:allium", "minecraft:short_grass", "minecraft:lily_of_the_valley"},
                    "minecraft:lantern"),
            new Palette("minecraft:snow_block", "minecraft:packed_ice", "minecraft:stone", "minecraft:blue_ice",
                    "minecraft:spruce_log", "minecraft:spruce_leaves[persistent=true]",
                    new String[] {"minecraft:snow", "minecraft:snow", "minecraft:sweet_berry_bush[age=3]"},
                    "minecraft:soul_lantern"),
            new Palette("minecraft:calcite", "minecraft:amethyst_block", "minecraft:tuff", "minecraft:purple_stained_glass",
                    null, null,
                    new String[] {"minecraft:amethyst_cluster[facing=up]", "minecraft:large_amethyst_bud[facing=up]",
                            "minecraft:medium_amethyst_bud[facing=up]"},
                    "minecraft:amethyst_cluster[facing=up]"),
            new Palette("minecraft:blackstone", "minecraft:basalt", "minecraft:blackstone", "minecraft:magma_block",
                    "minecraft:crimson_stem", "minecraft:nether_wart_block",
                    new String[] {"minecraft:crimson_roots", "minecraft:crimson_fungus", "minecraft:fire_coral_fan"},
                    "minecraft:shroomlight"),
            new Palette("minecraft:end_stone", "minecraft:end_stone_bricks", "minecraft:obsidian", "minecraft:crying_obsidian",
                    "minecraft:purpur_pillar", "minecraft:purpur_block",
                    new String[] {"minecraft:end_rod[facing=up]", "minecraft:chorus_flower[age=5]"},
                    "minecraft:end_rod[facing=up]"),
    };

    // ------------------------------------------------------------ трасса

    public static Layout generate(int bx, int by, int bz) {
        List<Sector> sectors = new ArrayList<>();
        List<Zone> zones = new ArrayList<>();
        List<V3[]> path = new ArrayList<>();
        double heading = 0;                       // 0 — на +Z
        V3 pos = new V3(bx, by + LOBBY_Y + 4, bz + 20);
        int order = 0;
        for (int s = 0; s < RINGS.length; s++) {
            int count = RINGS[s];
            double spacing = 32 - s * 0.8;
            double radius = 5.0 - s * 0.3;
            double turn = Math.toRadians(52.0 / count);
            double wiggle = Math.toRadians(7 + s * 3);
            int liftAt = count - 3;               // кольцо после восходящего потока
            List<V3> centers = new ArrayList<>();
            V3 p = pos;
            for (int i = 0; i < count; i++) {
                heading += turn + wiggle * Math.sin(order * 1.7 + s);
                double dy = i == liftAt ? LIFT_GAIN : -DESCENT + Math.sin(order * 2.3) * (0.6 + s * 0.2);
                // После потока — длиннее: успеть снизиться к следующему кольцу.
                double step = i == 0 ? 18 : i == liftAt + 1 ? spacing + 9 : spacing;
                p = p.add(Math.sin(heading) * step, dy, Math.cos(heading) * step);
                centers.add(p);
            }
            List<Ring> rings = new ArrayList<>();
            for (int i = 0; i < count; i++) {
                V3 prev = i == 0 ? pos : centers.get(i - 1);
                V3 next = i + 1 < count ? centers.get(i + 1)
                        : centers.get(i).add(centers.get(i).sub(prev));
                V3 normal = next.sub(prev).normalize();
                boolean last = s == RINGS.length - 1 && i == count - 1;
                Ring.Kind kind = last ? Ring.Kind.FINISH : i == count - 2 ? Ring.Kind.BOOST : Ring.Kind.NORMAL;
                rings.add(new Ring(order++, s, centers.get(i), normal, last ? 6 : radius, kind,
                        kind == Ring.Kind.BOOST ? 1.75 : 0));
            }
            // Восходящий поток между кольцами liftAt-1 и liftAt: поднимает на высоту следующего кольца.
            V3 a = centers.get(liftAt - 1), b = centers.get(liftAt);
            V3 la = a.lerp(b, 0.12), lb = a.lerp(b, 0.75);
            zones.add(new Zone(Zone.Kind.LIFT,
                    new V3(Math.min(la.x(), lb.x()) - 7, Math.min(a.y(), b.y()) - 14, Math.min(la.z(), lb.z()) - 7),
                    new V3(Math.max(la.x(), lb.x()) + 7, Math.max(a.y(), b.y()) - 3, Math.max(la.z(), lb.z()) + 7), 0.12));
            Checkpoint cp = Checkpoint.before(rings.get(0), 14, 1.5, 1.0);
            sectors.add(new Sector(s, SECTOR_NAMES[s], cp, rings));
            V3 from = cp.pos();
            for (Ring r : rings) {
                path.add(new V3[] {from, r.center(), new V3(r.radius(), 0, 0)});
                from = r.center();
            }
            pos = centers.get(count - 1);
        }
        Ring finishRing = sectors.get(sectors.size() - 1).rings().get(RINGS[RINGS.length - 1] - 1);
        V3 finishIsland = finishRing.center().add(finishRing.normal().mul(30)).add(0, -16, 0);
        finishIsland = new V3(Math.floor(finishIsland.x()), Math.floor(finishIsland.y()), Math.floor(finishIsland.z()));

        // Тренировка: круг из 6 колец за стартовым островом (на −Z).
        V3 tc = new V3(bx, by + LOBBY_Y + 14, bz - 64);
        List<Ring> training = new ArrayList<>();
        int tn = 6;
        for (int i = 0; i < tn; i++) {
            double ang = Math.PI / 2 + i * 2 * Math.PI / (tn + 1) + 0.35;
            V3 c = tc.add(Math.cos(ang) * 44, -i * 4.5, Math.sin(ang) * 44);
            V3 tangent = new V3(-Math.sin(ang), -0.12, Math.cos(ang)).normalize();
            training.add(new Ring(i, 0, c, tangent, 5, Ring.Kind.NORMAL, 0));
        }
        Checkpoint tStart = Checkpoint.before(training.get(0), 14, 1.5, 1.0);

        double minY = by + 84;
        double x0 = bx - 160, x1 = bx + 160, z0 = bz - 160, z1 = bz + 160;
        for (Sector s : sectors) for (Ring r : s.rings()) {
            x0 = Math.min(x0, r.center().x() - 120);
            x1 = Math.max(x1, r.center().x() + 120);
            z0 = Math.min(z0, r.center().z() - 120);
            z1 = Math.max(z1, r.center().z() + 120);
        }
        V3 min = new V3(Math.floor(x0), minY, Math.floor(z0)), max = new V3(Math.ceil(x1), by + 320, Math.ceil(z1));
        Track track = new Track(ID, NAME, VERSION, sectors, zones,
                new Track.Spot(new V3(bx + 0.5, by + LOBBY_Y + 1, bz + 6.5), 0),
                new Track.Spot(new V3(finishIsland.x() + 0.5, finishIsland.y() + 1, finishIsland.z() + 0.5),
                        V3.angles(finishRing.normal())[0]),
                tStart, training, min, max, minY, 2.4, 60, Track.OnMiss.ERROR);

        List<V3[]> fullPath = new ArrayList<>(path);
        V3 tf = tStart.pos();
        for (Ring r : training) {
            fullPath.add(new V3[] {tf, r.center(), new V3(r.radius(), 0, 0)});
            tf = r.center();
        }
        Blueprint bp = new Blueprint();
        Builder build = new Builder(bp, fullPath);
        decorate(build, track, bx, by, bz, finishIsland);
        return new Layout(track, bp, fullPath);
    }

    // ------------------------------------------------------------ острова

    static void decorate(Builder b, Track t, int bx, int by, int bz, V3 finish) {
        // Старт: большой остров, площадка и арка на выходе.
        int ly = by + LOBBY_Y;
        b.island(bx, ly, bz, 14, THEMES[0], 11);
        for (int x = -3; x <= 3; x++) for (int z = 2; z <= 9; z++) b.set(bx + x, ly, bz + z, "minecraft:smooth_quartz");
        for (int y = 1; y <= 6; y++) {
            b.set(bx - 4, ly + y, bz + 10, "minecraft:purpur_pillar");
            b.set(bx + 4, ly + y, bz + 10, "minecraft:purpur_pillar");
        }
        for (int x = -4; x <= 4; x++) b.set(bx + x, ly + 7, bz + 10, x == 0 ? "minecraft:sea_lantern" : "minecraft:purpur_slab");
        b.set(bx - 3, ly + 1, bz + 2, "minecraft:lantern");
        b.set(bx + 3, ly + 1, bz + 2, "minecraft:lantern");

        long seed = 17;
        for (Sector s : t.sectors) {
            Palette pal = THEMES[s.index()];
            // Остров сектора — под контрольной точкой, с маяком-кристаллом.
            V3 cp = s.checkpoint().pos();
            int cx = (int) Math.floor(cp.x()), cz = (int) Math.floor(cp.z()), cy = (int) Math.floor(cp.y()) - 20;
            b.island(cx, cy, cz, 9, pal, seed++);
            b.pillar(cx, cy + 1, cz, 5, pal.accent(), pal.light());
            for (Ring r : s.rings()) {
                // Острова сбоку от колец, по очереди слева и справа.
                V3 side = new V3(-r.normal().z(), 0, r.normal().x()).normalize();
                double dir = (r.order() % 2 == 0) ? 1 : -1;
                double off = r.radius() + 16 + (hash(seed) % 9);
                V3 c = r.center().add(side.mul(dir * off)).add(0, -8 - (hash(seed + 5) % 10), 0);
                int size = 4 + (int) (hash(seed + 9) % 5);
                b.island((int) Math.floor(c.x()), (int) Math.floor(c.y()), (int) Math.floor(c.z()), size, pal, seed++);
            }
        }
        // Восходящие потоки: остров-«вентиль» под каждым.
        for (Zone z : t.zones) {
            int x = (int) Math.floor((z.min().x() + z.max().x()) / 2), zz = (int) Math.floor((z.min().z() + z.max().z()) / 2);
            int y = (int) Math.floor(z.min().y()) - 4;
            b.vent(x, y, zz);
        }
        // Финиш: остров с разломом.
        int fx = (int) finish.x(), fy = (int) finish.y(), fz = (int) finish.z();
        b.island(fx, fy, fz, 16, THEMES[5], 99);
        b.rift(fx, fy + 1, fz);
        // Тренировка: маленькие острова в центре круга.
        b.island(bx, ly - 10, bz - 64, 7, THEMES[1], 5);
        b.island(bx + 12, ly - 16, bz - 58, 4, THEMES[0], 6);
    }

    static long hash(long x) {
        x = (x ^ (x >>> 33)) * 0xff51afd7ed558ccdL;
        x = (x ^ (x >>> 33)) * 0xc4ceb9fe1a85ec53L;
        return (x ^ (x >>> 33)) & Long.MAX_VALUE;
    }

    /** Постановка блоков с проверкой: рядом с линией полёта ничего не ставим. */
    static final class Builder {
        final Blueprint bp;
        final List<V3[]> path;
        int skipped;

        Builder(Blueprint bp, List<V3[]> path) {
            this.bp = bp;
            this.path = path;
        }

        boolean free(int x, int y, int z) {
            V3 p = new V3(x + 0.5, y + 0.5, z + 0.5);
            for (V3[] seg : path) {
                double r = seg[2].x() + CLEARANCE;
                if (distanceToSegment(p, seg[0], seg[1]) < r) return false;
            }
            return true;
        }

        void set(int x, int y, int z, String block) {
            if (free(x, y, z)) bp.set(x, y, z, block);
            else skipped++;
        }

        /** Парящий остров: травяной верх, слой почвы, каменный «сталактит» вниз. */
        void island(int cx, int cy, int cz, int r, Palette pal, long seed) {
            int depth = Math.max(4, (int) Math.round(r * 1.3));
            for (int dy = 0; dy <= depth; dy++) {
                double k = 1 - (double) dy / (depth + 1);
                double rr = r * Math.sqrt(k) + 0.3;
                for (int dx = -r; dx <= r; dx++) {
                    for (int dz = -r; dz <= r; dz++) {
                        double d = Math.sqrt(dx * dx + dz * dz);
                        double edge = rr - (hash(seed * 1315423911L + dx * 31L + dz * 977L + dy) % 100) / 140.0;
                        if (d > edge) continue;
                        String block = dy == 0 ? pal.top() : dy <= 2 ? pal.soil()
                                : (hash(seed + dx * 7L + dz * 13L + dy * 17L) % 9 == 0 ? pal.accent() : pal.core());
                        set(cx + dx, cy - dy, cz + dz, block);
                    }
                }
            }
            // Сверху: деревья, цветы, фонари.
            int trees = pal.log() == null ? 0 : Math.max(1, r / 4);
            for (int i = 0; i < trees; i++) {
                int tx = cx + (int) (hash(seed + 100 + i) % (r)) - r / 2;
                int tz = cz + (int) (hash(seed + 200 + i) % (r)) - r / 2;
                tree(tx, cy + 1, tz, 4 + (int) (hash(seed + 300 + i) % 3), pal);
            }
            int smalls = r * 2;
            for (int i = 0; i < smalls; i++) {
                int dx = (int) (hash(seed + 400 + i) % (2L * r - 1)) - (r - 1);
                int dz = (int) (hash(seed + 500 + i) % (2L * r - 1)) - (r - 1);
                if (dx * dx + dz * dz > (r - 1) * (r - 1)) continue;
                if (!pal.top().equals(bp.get(cx + dx, cy, cz + dz))) continue;
                if (bp.has(cx + dx, cy + 1, cz + dz)) continue;
                String what = pal.small()[(int) (hash(seed + 600 + i) % pal.small().length)];
                set(cx + dx, cy + 1, cz + dz, what);
            }
            if (r >= 6) set(cx + r / 2, cy + 1, cz - r / 2, pal.light());
        }

        void tree(int x, int y, int z, int h, Palette pal) {
            for (int i = 0; i < h; i++) set(x, y + i, z, pal.log());
            int top = y + h - 1;
            for (int dx = -2; dx <= 2; dx++)
                for (int dy = -1; dy <= 2; dy++)
                    for (int dz = -2; dz <= 2; dz++) {
                        int d = Math.abs(dx) + Math.abs(dz) + Math.max(0, dy);
                        if (d > 3 || (dx == 0 && dz == 0 && dy < 1)) continue;
                        if (!bp.has(x + dx, top + dy, z + dz)) set(x + dx, top + dy, z + dz, pal.leaves());
                    }
        }

        void pillar(int x, int y, int z, int h, String block, String light) {
            for (int i = 0; i < h; i++) set(x, y + i, z, block);
            set(x, y + h, z, light);
        }

        /** Основание восходящего потока: голубое кольцо и фонари. */
        void vent(int x, int y, int z) {
            for (int dx = -5; dx <= 5; dx++)
                for (int dz = -5; dz <= 5; dz++) {
                    double d = Math.sqrt(dx * dx + dz * dz);
                    if (d > 5.3) continue;
                    set(x + dx, y, z + dz, d > 3.6 ? "minecraft:prismarine_bricks" : d > 2.2
                            ? "minecraft:light_blue_stained_glass" : "minecraft:sea_lantern");
                    if (d <= 4.5) set(x + dx, y - 1, z + dz, "minecraft:dark_prismarine");
                    if (d <= 2.5) set(x + dx, y - 2, z + dz, "minecraft:prismarine");
                }
            for (int[] c : new int[][] {{5, 0}, {-5, 0}, {0, 5}, {0, -5}}) set(x + c[0], y + 1, z + c[1], "minecraft:soul_lantern");
        }

        /** Разлом на финише: рамка из обсидиана с фиолетовым «стеклом» и колонны. */
        void rift(int x, int y, int z) {
            for (int dx = -3; dx <= 3; dx++)
                for (int dy = 0; dy <= 8; dy++) {
                    boolean frame = Math.abs(dx) == 3 || dy == 0 || dy == 8;
                    set(x + dx, y + dy, z, frame ? (dy % 3 == 1 ? "minecraft:crying_obsidian" : "minecraft:obsidian")
                            : "minecraft:purple_stained_glass");
                }
            for (int[] c : new int[][] {{-7, -5}, {7, -5}, {-7, 5}, {7, 5}}) pillar(x + c[0], y, z + c[1], 5, "minecraft:purpur_pillar", "minecraft:end_rod[facing=up]");
        }
    }

    public static double distanceToSegment(V3 p, V3 a, V3 b) {
        V3 ab = b.sub(a);
        double len = ab.lengthSq();
        double t = len < 1e-9 ? 0 : Math.max(0, Math.min(1, p.sub(a).dot(ab) / len));
        return p.distance(a.add(ab.mul(t)));
    }
}
