package dev.dirronlive.parkour.world;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

/**
 * Временные блоки действий (мост, срезка, страховка, исчезающая ступень).
 *
 * <p>На одну позицию можно наложить несколько эффектов: виден последний
 * действующий, а когда все закончились, блок возвращается к чертежу карты.
 * Позиции запоминаются в сохранении мира, поэтому после перезапуска
 * карта исправляется даже если игра закрылась посреди эффекта.
 */
public final class TempBlocks {
    static final int FLAGS = Block.NOTIFY_LISTENERS | Block.FORCE_STATE;

    record Layer(long effect, BlockState state, long until) {}

    private final Map<BlockPos, List<Layer>> layers = new HashMap<>();
    /** Что стояло на позиции до первого эффекта — это и возвращаем. */
    private final Map<BlockPos, BlockState> original = new HashMap<>();
    private final Function<BlockPos, BlockState> blueprint;
    private final ParkourState state;
    private long nextEffect = 1;

    public TempBlocks(Function<BlockPos, BlockState> blueprint, ParkourState state) {
        this.blueprint = blueprint;
        this.state = state;
    }

    /** Ставит блоки на {@code ticks} тиков. Возвращает id эффекта. */
    public long place(ServerWorld world, Collection<BlockPos> positions, BlockState block, long now, int ticks) {
        long id = nextEffect++;
        for (BlockPos raw : positions) {
            BlockPos pos = raw.toImmutable();
            if (!layers.containsKey(pos)) original.put(pos, world.getBlockState(pos));
            layers.computeIfAbsent(pos, k -> new ArrayList<>()).add(new Layer(id, block, now + ticks));
            world.setBlockState(pos, block, FLAGS);
            state.dirty.add(pos.asLong());
        }
        state.markDirty();
        return id;
    }

    public boolean isTemporary(BlockPos pos) {
        return layers.containsKey(pos);
    }

    public int activeCount() {
        return layers.size();
    }

    /** Снимает закончившиеся эффекты. */
    public void tick(ServerWorld world, long now) {
        if (layers.isEmpty()) return;
        Iterator<Map.Entry<BlockPos, List<Layer>>> it = layers.entrySet().iterator();
        boolean changed = false;
        while (it.hasNext()) {
            Map.Entry<BlockPos, List<Layer>> e = it.next();
            List<Layer> list = e.getValue();
            if (!list.removeIf(l -> l.until() <= now)) continue;
            changed = true;
            if (list.isEmpty()) {
                world.setBlockState(e.getKey(), restored(e.getKey()), FLAGS);
                state.dirty.remove(e.getKey().asLong());
                it.remove();
            } else {
                world.setBlockState(e.getKey(), list.get(list.size() - 1).state(), FLAGS);
            }
        }
        if (changed) state.markDirty();
    }

    /** Немедленно убирает все эффекты в области (игрок ушёл из комнаты). */
    public void clear(ServerWorld world, Predicate<BlockPos> area) {
        Iterator<Map.Entry<BlockPos, List<Layer>>> it = layers.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<BlockPos, List<Layer>> e = it.next();
            if (!area.test(e.getKey())) continue;
            world.setBlockState(e.getKey(), restored(e.getKey()), FLAGS);
            state.dirty.remove(e.getKey().asLong());
            it.remove();
        }
        state.markDirty();
    }

    /** Исходный блок позиции (или блок чертежа, если исходный неизвестен). */
    private BlockState restored(BlockPos pos) {
        BlockState was = original.remove(pos);
        return was != null ? was : blueprint.apply(pos);
    }

    public void clearAll(ServerWorld world) {
        clear(world, pos -> true);
    }

    /** После загрузки мира: вернуть по чертежу всё, что осталось от прошлых эффектов. */
    public void repairAfterRestart(ServerWorld world) {
        if (state.dirty.isEmpty()) return;
        for (long packed : List.copyOf(state.dirty)) {
            BlockPos pos = BlockPos.fromLong(packed);
            if (!layers.containsKey(pos)) world.setBlockState(pos, blueprint.apply(pos), FLAGS);
        }
        state.dirty.clear();
        state.markDirty();
    }
}
