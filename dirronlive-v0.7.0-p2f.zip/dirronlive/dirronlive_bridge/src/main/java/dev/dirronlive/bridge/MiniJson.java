package dev.dirronlive.bridge;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Крошечный JSON для протокола Dirronlive: объекты со строками, числами,
 * true/false/null, вложенными объектами (→ Map) и массивами (→ List).
 * Без внешних библиотек, поэтому код мода можно проверять обычными
 * тестами без Minecraft.
 */
public final class MiniJson {
    private MiniJson() {}

    /** Собирает плоский JSON-объект. Значения: String, Number, Boolean или null. */
    public static String object(Object... keysAndValues) {
        if (keysAndValues.length % 2 != 0) throw new IllegalArgumentException("нечётное число аргументов");
        StringBuilder out = new StringBuilder("{");
        for (int i = 0; i < keysAndValues.length; i += 2) {
            if (i > 0) out.append(',');
            quote(out, String.valueOf(keysAndValues[i]));
            out.append(':');
            write(out, keysAndValues[i + 1]);
        }
        return out.append('}').toString();
    }

    /** Готовый JSON, который вставляется как есть. */
    public record Raw(String json) {}

    /** Любое значение: String, Number, Boolean, null, Map, List (вложенные), {@link Raw}. */
    public static String write(Object value) {
        StringBuilder out = new StringBuilder();
        write(out, value);
        return out.toString();
    }

    private static void write(StringBuilder out, Object value) {
        if (value == null) out.append("null");
        else if (value instanceof Raw raw) out.append(raw.json());
        else if (value instanceof Boolean || value instanceof Integer || value instanceof Long) out.append(value);
        else if (value instanceof Number n) {
            double d = n.doubleValue();
            if (Double.isNaN(d) || Double.isInfinite(d)) out.append("0");
            else if (d == Math.rint(d) && Math.abs(d) < 1e15) out.append((long) d).append(".0");
            else out.append(d);
        } else if (value instanceof Map<?, ?> map) {
            out.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> e : map.entrySet()) {
                if (!first) out.append(',');
                first = false;
                quote(out, String.valueOf(e.getKey()));
                out.append(':');
                write(out, e.getValue());
            }
            out.append('}');
        } else if (value instanceof Iterable<?> list) {
            out.append('[');
            boolean first = true;
            for (Object o : list) {
                if (!first) out.append(',');
                first = false;
                write(out, o);
            }
            out.append(']');
        } else quote(out, value.toString());
    }

    private static void quote(StringBuilder out, String s) {
        out.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                case '\b' -> out.append("\\b");
                case '\f' -> out.append("\\f");
                default -> {
                    if (c < 0x20) out.append(String.format("\\u%04x", (int) c));
                    else out.append(c);
                }
            }
        }
        out.append('"');
    }

    /**
     * Разбирает JSON-объект верхнего уровня. Строки → String, числа → Long
     * или Double, true/false → Boolean, null → null, объект → Map, массив → List.
     *
     * @throws IllegalArgumentException если текст не JSON-объект
     */
    public static Map<String, Object> parseObject(String text) {
        Parser p = new Parser(text);
        p.skipWs();
        Map<String, Object> result = p.readObject(true);
        p.skipWs();
        if (!p.atEnd()) throw p.error("лишние символы после объекта");
        return result;
    }

    private static final class Parser {
        private final String s;
        private int i;

        Parser(String s) {
            this.s = s == null ? "" : s;
        }

        boolean atEnd() {
            return i >= s.length();
        }

        IllegalArgumentException error(String what) {
            return new IllegalArgumentException("JSON: " + what + " (позиция " + i + ")");
        }

        void skipWs() {
            while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++;
        }

        char peek() {
            if (atEnd()) throw error("неожиданный конец");
            return s.charAt(i);
        }

        void expect(char c) {
            if (peek() != c) throw error("ожидался '" + c + "'");
            i++;
        }

        Map<String, Object> readObject(boolean keep) {
            expect('{');
            Map<String, Object> map = keep ? new LinkedHashMap<>() : null;
            skipWs();
            if (peek() == '}') {
                i++;
                return map;
            }
            while (true) {
                skipWs();
                String key = readString();
                skipWs();
                expect(':');
                skipWs();
                Object value = readValue();
                if (map != null) map.put(key, value);
                skipWs();
                char c = peek();
                i++;
                if (c == '}') return map;
                if (c != ',') throw error("ожидалась ',' или '}'");
            }
        }

        List<Object> readArray() {
            expect('[');
            List<Object> list = new ArrayList<>();
            skipWs();
            if (peek() == ']') {
                i++;
                return list;
            }
            while (true) {
                skipWs();
                list.add(readValue());
                skipWs();
                char c = peek();
                i++;
                if (c == ']') return list;
                if (c != ',') throw error("ожидалась ',' или ']'");
            }
        }

        int depth;

        Object readValue() {
            char c = peek();
            if (c == '"') return readString();
            if (c == '{' || c == '[') {
                if (++depth > 16) throw error("слишком глубокая вложенность");
                try {
                    return c == '{' ? readObject(true) : readArray();
                } finally {
                    depth--;
                }
            }
            if (s.startsWith("true", i)) {
                i += 4;
                return Boolean.TRUE;
            }
            if (s.startsWith("false", i)) {
                i += 5;
                return Boolean.FALSE;
            }
            if (s.startsWith("null", i)) {
                i += 4;
                return null;
            }
            return readNumber();
        }

        Object readNumber() {
            int start = i;
            if (peek() == '-') i++;
            boolean fraction = false;
            while (!atEnd()) {
                char c = s.charAt(i);
                if (c >= '0' && c <= '9') i++;
                else if (c == '.' || c == 'e' || c == 'E' || c == '+' || c == '-') {
                    fraction = true;
                    i++;
                } else break;
            }
            String number = s.substring(start, i);
            if (number.isEmpty() || number.equals("-")) throw error("ожидалось значение");
            try {
                return fraction ? (Object) Double.parseDouble(number) : (Object) Long.parseLong(number);
            } catch (NumberFormatException e) {
                throw error("неверное число " + number);
            }
        }

        String readString() {
            expect('"');
            StringBuilder out = new StringBuilder();
            while (true) {
                char c = peek();
                i++;
                if (c == '"') return out.toString();
                if (c != '\\') {
                    out.append(c);
                    continue;
                }
                char e = peek();
                i++;
                switch (e) {
                    case '"' -> out.append('"');
                    case '\\' -> out.append('\\');
                    case '/' -> out.append('/');
                    case 'b' -> out.append('\b');
                    case 'f' -> out.append('\f');
                    case 'n' -> out.append('\n');
                    case 'r' -> out.append('\r');
                    case 't' -> out.append('\t');
                    case 'u' -> {
                        if (i + 4 > s.length()) throw error("обрезанный \\u");
                        try {
                            out.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                        } catch (NumberFormatException ex) {
                            throw error("неверный \\u");
                        }
                        i += 4;
                    }
                    default -> throw error("неизвестная escape-последовательность");
                }
            }
        }
    }
}
