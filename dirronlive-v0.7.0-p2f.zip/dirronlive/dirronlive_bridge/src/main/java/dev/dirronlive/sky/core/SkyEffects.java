package dev.dirronlive.sky.core;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/**
 * Действия зрителей в полёте: 10 эффектов, лимиты, конфликты, перезарядки,
 * ограниченная очередь со сроком ожидания и ответы программе
 * (принято / запущено / завершено / отложено / отклонено — с причиной).
 *
 * <p>Правила:
 * <ul>
 *   <li>одновременно не больше {@link #MAX_MOVEMENT} эффектов движения и
 *       не больше {@link #MAX_EXPENSIVE} дорогого события;</li>
 *   <li>попутный поток и воздушный тормоз не идут вместе;</li>
 *   <li>повтор идущего эффекта: extend — продлить, queue — после него,
 *       ignore — отклонить;</li>
 *   <li>после конца эффекта — перезарядка, пока она идёт, новый ждёт в очереди;</li>
 *   <li>в очереди не больше {@link #MAX_QUEUE}, ждать можно {@link #QUEUE_TTL} тиков;</li>
 *   <li>3 секунды защиты после возврата: силы не действуют, новые не стартуют;</li>
 *   <li>одно событие (id) выполняется один раз, повтор получает прошлый ответ.</li>
 * </ul>
 * Время эффектов идёт только во время полёта: на паузе всё замирает.
 */
public final class SkyEffects {
    public enum Tier { CHEAP, MEDIUM, EXPENSIVE }

    public enum Kind {
        CROSSWIND("crosswind", "Боковой ветер", Tier.CHEAP, true, 5, 8),
        HEAVY_WINGS("heavy_wings", "Тяжёлые крылья", Tier.CHEAP, true, 6, 8),
        TAILWIND("tailwind", "Попутный поток", Tier.CHEAP, true, 5, 8),
        TURBULENCE("turbulence", "Турбулентность", Tier.MEDIUM, true, 6, 15),
        NARROW("narrow", "Узкий проход", Tier.MEDIUM, false, 12, 20),
        AIR_BRAKE("air_brake", "Воздушный тормоз", Tier.MEDIUM, true, 4, 15),
        STORM("storm", "Грозовой фронт", Tier.EXPENSIVE, true, 8, 40),
        TIME_RIFT("time_rift", "Временной разлом", Tier.EXPENSIVE, false, 2, 45),
        SLALOM("slalom", "Небесный слалом", Tier.EXPENSIVE, false, 15, 45),
        GUARDIAN("guardian", "Ангел-хранитель", Tier.EXPENSIVE, false, 30, 60);

        public final String id;
        public final String title;
        public final Tier tier;
        public final boolean movement;
        public final int seconds;
        public final int cooldown;

        Kind(String id, String title, Tier tier, boolean movement, int seconds, int cooldown) {
            this.id = id;
            this.title = title;
            this.tier = tier;
            this.movement = movement;
            this.seconds = seconds;
            this.cooldown = cooldown;
        }

        public static Kind of(String id) {
            for (Kind k : values()) if (k.id.equals(id)) return k;
            return null;
        }
    }

    public static final int MAX_MOVEMENT = 2;
    public static final int MAX_EXPENSIVE = 1;
    public static final int MAX_QUEUE = 10;
    public static final int QUEUE_TTL = 45 * 20;
    public static final int REMEMBER = 2000;
    public static final int JOURNAL = 60;

    public record Request(String id, String action, double strength, int seconds, int cooldown, String repeat,
                          String viewer, boolean test) {}

    /** Ответ программе. state: accepted, started, finished, deferred, rejected. */
    public record Ack(String id, String action, String state, String reason) {}

    /** Подсказка игре: что сделать в мире прямо сейчас. */
    public record Cue(Type type, Kind kind, double value, V3 vector) {
        public enum Type { LIGHTNING, REWIND, SHIELD_ON, SHIELD_OFF, GATE_PASS, GATE_MISS, STARTED, ENDED }
    }

    /** Что нужно знать о полёте в момент запуска эффекта. */
    public record Context(V3 position, V3 velocity, Ring next, Ring after) {}

    public record Gate(Ring ring, boolean done) {}

    public static final class Active {
        public final Kind kind;
        public final String id;
        public final String viewer;
        public final double strength;
        int left;
        int total;
        V3 push = V3.ZERO;
        final Random random;

        Active(Kind kind, String id, String viewer, double strength, int ticks, long seed) {
            this.kind = kind;
            this.id = id;
            this.viewer = viewer;
            this.strength = strength;
            this.left = ticks;
            this.total = ticks;
            this.random = new Random(seed);
        }

        public int secondsLeft() {
            return (left + 19) / 20;
        }
    }

    static final class Waiting {
        final Request request;
        final Kind kind;
        int age;

        Waiting(Request request, Kind kind) {
            this.request = request;
            this.kind = kind;
        }
    }

    public static final class Result {
        public final List<Ack> acks = new ArrayList<>(2);
        public final List<Cue> cues = new ArrayList<>(2);

        public boolean isEmpty() {
            return acks.isEmpty() && cues.isEmpty();
        }
    }

    private final List<Active> active = new ArrayList<>(4);
    private final ArrayDeque<Waiting> queue = new ArrayDeque<>();
    private final Map<Kind, Integer> cooldownLeft = new HashMap<>();
    private final Map<Kind, Integer> cooldownOf = new HashMap<>();
    private final LinkedHashMap<String, String> seen = new LinkedHashMap<>(256, 0.75f, false) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
            return size() > REMEMBER;
        }
    };
    private final ArrayDeque<String> journal = new ArrayDeque<>();
    private final List<Gate> gates = new ArrayList<>();
    private long clock;

    // ------------------------------------------------------------- приём

    /**
     * Новое событие. {@code canRun} — заезд идёт (или отсчёт/пауза: тогда в очередь),
     * {@code flying} — прямо сейчас полёт без защиты, можно запускать сразу.
     */
    public Result submit(Request r, boolean canRun, boolean flying, Context ctx) {
        Result out = new Result();
        String last = seen.get(r.id());
        if (last != null) {
            out.acks.add(new Ack(r.id(), r.action(), last, "повтор события — уже обработано"));
            return out;
        }
        Kind kind = Kind.of(r.action());
        if (kind == null) {
            reject(out, r, "неизвестное действие");
            return out;
        }
        if (!canRun) {
            reject(out, r, "заезд не идёт");
            return out;
        }
        accept(out, r);
        Active same = find(kind);
        if (same != null) {
            switch (r.repeat() == null ? "extend" : r.repeat()) {
                case "ignore" -> {
                    reject(out, r, kind.title + " уже идёт");
                    return out;
                }
                case "queue" -> {
                    defer(out, r, kind, kind.title + " уже идёт — после него");
                    return out;
                }
                default -> {
                    int add = ticks(r, kind);
                    int cap = Math.max(add, same.total) * 3;
                    same.left = Math.min(cap, same.left + add);
                    same.total = Math.max(same.total, same.left);
                    mark(out, r, "started", "продлён до " + same.secondsLeft() + " с");
                    log(r, kind, "продлён");
                    return out;
                }
            }
        }
        String blocked = blocked(kind, r.test(), flying);
        if (blocked == null) {
            start(out, r, kind, ctx);
        } else {
            defer(out, r, kind, blocked);
        }
        return out;
    }

    /** Почему эффект нельзя запустить прямо сейчас ({@code null} — можно). */
    String blocked(Kind kind, boolean test, boolean flying) {
        if (!flying) return "ждём полёта";
        if (!test) {
            Integer cd = cooldownLeft.get(kind);
            if (cd != null && cd > 0) return "перезарядка " + ((cd + 19) / 20) + " с";
        }
        if (kind.movement && count(true, null) >= MAX_MOVEMENT) return "уже " + MAX_MOVEMENT + " эффекта движения";
        if (kind.tier == Tier.EXPENSIVE && count(false, Tier.EXPENSIVE) >= MAX_EXPENSIVE) {
            return "идёт дорогое событие";
        }
        Kind rival = kind == Kind.TAILWIND ? Kind.AIR_BRAKE : kind == Kind.AIR_BRAKE ? Kind.TAILWIND : null;
        if (rival != null && find(rival) != null) return "мешает «" + rival.title + "»";
        if (kind == Kind.SLALOM && !gates.isEmpty()) return "слалом ещё идёт";
        return null;
    }

    int count(boolean movement, Tier tier) {
        int n = 0;
        for (Active a : active) {
            if (movement && a.kind.movement) n++;
            else if (!movement && a.kind.tier == tier) n++;
        }
        return n;
    }

    Active find(Kind kind) {
        for (Active a : active) if (a.kind == kind) return a;
        return null;
    }

    static int ticks(Request r, Kind kind) {
        int s = r.seconds() > 0 ? r.seconds() : kind.seconds;
        return Math.max(1, s) * 20;
    }

    private void start(Result out, Request r, Kind kind, Context ctx) {
        Active a = new Active(kind, r.id(), r.viewer() == null ? "" : r.viewer(), r.strength() <= 0 ? 1 : r.strength(),
                ticks(r, kind), r.id().hashCode() * 31L + clock);
        cooldownOf.put(kind, (r.cooldown() > 0 ? r.cooldown() : kind.cooldown) * 20);
        switch (kind) {
            case CROSSWIND -> {
                V3 v = ctx == null ? V3.ZERO : ctx.velocity();
                V3 side = new V3(-v.z(), 0, v.x()).normalize();
                if (side.lengthSq() == 0) side = new V3(1, 0, 0);
                a.push = side.mul((a.random.nextBoolean() ? 1 : -1) * 0.035 * a.strength);
            }
            case STORM -> a.push = gust(a);
            case TIME_RIFT -> out.cues.add(new Cue(Cue.Type.REWIND, kind,
                    Math.max(2, Math.min(6, Math.round(3 * a.strength))), null));
            case SLALOM -> {
                gates.clear();
                if (ctx != null && ctx.next() != null) gates.addAll(slalom(ctx, a.strength));
            }
            case GUARDIAN -> out.cues.add(new Cue(Cue.Type.SHIELD_ON, kind, 0, null));
            default -> {}
        }
        active.add(a);
        out.cues.add(new Cue(Cue.Type.STARTED, kind, a.strength, null));
        mark(out, r, "started", kind.title + " · " + a.secondsLeft() + " с");
        log(r, kind, "запущено");
    }

    private V3 gust(Active a) {
        double ang = a.random.nextDouble() * Math.PI * 2;
        return new V3(Math.cos(ang), 0, Math.sin(ang)).mul(0.045 * a.strength);
    }

    /** Ворота слалома между игроком и следующим кольцом: влево-вправо по очереди. */
    static List<Gate> slalom(Context ctx, double strength) {
        V3 from = ctx.position();
        V3 to = ctx.next().center();
        if (to.distance(from) < 30 && ctx.after() != null) to = ctx.after().center();
        V3 path = to.sub(from);
        double len = path.length();
        List<Gate> out = new ArrayList<>(3);
        if (len < 18) return out;
        V3 dir = path.normalize();
        V3 side = new V3(-dir.z(), 0, dir.x()).normalize();
        if (side.lengthSq() == 0) side = new V3(1, 0, 0);
        double offset = Math.min(7, 3.5 * strength + 1);
        double[] at = {0.35, 0.6, 0.85};
        for (int i = 0; i < at.length; i++) {
            V3 c = from.add(path.mul(at[i])).add(side.mul(i % 2 == 0 ? offset : -offset));
            out.add(new Gate(new Ring(i, -1, c, dir, 2.5, Ring.Kind.NORMAL, 0), false));
        }
        return out;
    }

    // --------------------------------------------------------------- тик

    /**
     * Один тик. {@code running} — заезд идёт (не пауза, не отсчёт);
     * {@code protection} — защита после возврата; {@code from/to} — отрезок
     * движения для ворот слалома.
     */
    public Result tick(boolean running, boolean protection, boolean teleported, V3 from, V3 to, Context ctx) {
        Result out = new Result();
        if (!running) return out;
        clock++;
        cooldownLeft.replaceAll((k, v) -> Math.max(0, v - 1));
        for (Iterator<Active> it = active.iterator(); it.hasNext(); ) {
            Active a = it.next();
            a.left--;
            if (a.kind == Kind.STORM && a.left > 0 && a.left % 30 == 0) {
                a.push = gust(a);
                out.cues.add(new Cue(Cue.Type.LIGHTNING, a.kind, a.strength, a.push));
            }
            if (a.left <= 0) {
                it.remove();
                end(out, a, "время вышло");
            }
        }
        if (!gates.isEmpty() && !teleported && from != null && to != null && from.distance(to) <= SkyRun.MAX_STEP) {
            for (int i = 0; i < gates.size(); i++) {
                Gate g = gates.get(i);
                if (g.done()) continue;
                RingCheck.Result r = RingCheck.cross(from, to, g.ring());
                if (r == RingCheck.Result.HIT) {
                    gates.set(i, new Gate(g.ring(), true));
                    out.cues.add(new Cue(Cue.Type.GATE_PASS, Kind.SLALOM, i, g.ring().center()));
                } else if (r == RingCheck.Result.MISS || farMiss(from, to, g.ring())) {
                    gates.set(i, new Gate(g.ring(), true));
                    out.cues.add(new Cue(Cue.Type.GATE_MISS, Kind.SLALOM, i, g.ring().center()));
                }
            }
            if (gates.stream().allMatch(Gate::done)) {
                gates.clear();
                Active s = find(Kind.SLALOM);
                if (s != null) {
                    active.remove(s);
                    end(out, s, "все ворота позади");
                }
            }
        }
        if (find(Kind.SLALOM) == null) gates.clear();
        for (Iterator<Waiting> it = queue.iterator(); it.hasNext(); ) {
            Waiting w = it.next();
            if (++w.age > QUEUE_TTL) {
                it.remove();
                reject(out, w.request, "истекло время ожидания");
            }
        }
        if (!protection) {
            for (Iterator<Waiting> it = queue.iterator(); it.hasNext(); ) {
                Waiting w = it.next();
                if (find(w.kind) != null) continue;
                if (blocked(w.kind, w.request.test(), true) == null) {
                    it.remove();
                    start(out, w.request, w.kind, ctx);
                }
            }
        }
        return out;
    }

    /** Пролёт плоскости ворот дальше, чем засчитывается промах кольца, — тоже мимо ворот. */
    static boolean farMiss(V3 from, V3 to, Ring ring) {
        double d0 = from.sub(ring.center()).dot(ring.normal());
        double d1 = to.sub(ring.center()).dot(ring.normal());
        return d0 < 0 && d1 >= 0;
    }

    private void end(Result out, Active a, String reason) {
        cooldownLeft.put(a.kind, cooldownOf.getOrDefault(a.kind, a.kind.cooldown * 20));
        if (a.kind == Kind.GUARDIAN) out.cues.add(new Cue(Cue.Type.SHIELD_OFF, a.kind, 0, null));
        if (a.kind == Kind.SLALOM) gates.clear();
        out.cues.add(new Cue(Cue.Type.ENDED, a.kind, 0, null));
        out.acks.add(new Ack(a.id, a.kind.id, "finished", reason));
        seen.put(a.id, "finished");
        journal(a.kind.title + " · завершено · " + reason + (a.viewer.isEmpty() ? "" : " · " + a.viewer));
    }

    /** Закончить эффект раньше (щит ангела использован). */
    public Result endEarly(Kind kind, String reason) {
        Result out = new Result();
        Active a = find(kind);
        if (a != null) {
            active.remove(a);
            end(out, a, reason);
        }
        return out;
    }

    /** Заезд перезапущен или остановлен: всё идущее завершается, очередь отклоняется. */
    public Result reset(String reason) {
        Result out = new Result();
        for (Active a : new ArrayList<>(active)) {
            active.remove(a);
            end(out, a, reason);
        }
        while (!queue.isEmpty()) reject(out, queue.poll().request, reason);
        gates.clear();
        cooldownLeft.clear();
        return out;
    }

    // ------------------------------------------------------------- силы

    /** Сумма сил идущих эффектов. В защите после возврата — никаких. */
    public Forces forces(boolean protection) {
        if (protection || active.isEmpty()) return Forces.NONE;
        V3 push = V3.ZERO;
        double tail = 0, sink = 0, drag = 1, turb = 0, cap = 1;
        for (Active a : active) {
            double s = a.strength;
            switch (a.kind) {
                case CROSSWIND -> push = push.add(a.push);
                case HEAVY_WINGS -> sink += 0.03 * s;
                case TAILWIND -> {
                    tail += 0.04 * s;
                    cap *= 1.15;
                }
                case TURBULENCE -> turb += 0.05 * s;
                case AIR_BRAKE -> {
                    drag *= Math.max(0.85, 1 - 0.03 * s);
                    cap *= Math.max(0.4, 1 - 0.35 * s);
                }
                case STORM -> {
                    push = push.add(a.push);
                    sink += 0.01 * s;
                    turb += 0.02 * s;
                }
                default -> {}
            }
        }
        return new Forces(push, tail, sink, drag, turb, cap);
    }

    /** Размер колец при «Узком проходе». */
    public double ringScale() {
        Active a = find(Kind.NARROW);
        return a == null ? 1 : Math.max(0.45, 1 - 0.35 * a.strength);
    }

    // ---------------------------------------------------------- данные

    public List<SkyStatus.Effect> status() {
        List<SkyStatus.Effect> out = new ArrayList<>(active.size());
        for (Active a : active) out.add(new SkyStatus.Effect(a.kind.id, a.secondsLeft(), a.viewer));
        return out;
    }

    public List<Active> active() {
        return List.copyOf(active);
    }

    public boolean isActive(Kind kind) {
        return find(kind) != null;
    }

    public List<Gate> gates() {
        return List.copyOf(gates);
    }

    public int queued() {
        return queue.size();
    }

    public List<String> journal() {
        return List.copyOf(journal);
    }

    // ---------------------------------------------------------- ответы

    private void accept(Result out, Request r) {
        out.acks.add(new Ack(r.id(), r.action(), "accepted", ""));
        seen.put(r.id(), "accepted");
    }

    private void mark(Result out, Request r, String state, String reason) {
        out.acks.add(new Ack(r.id(), r.action(), state, reason));
        seen.put(r.id(), state);
    }

    private void reject(Result out, Request r, String reason) {
        out.acks.add(new Ack(r.id(), r.action(), "rejected", reason));
        seen.put(r.id(), "rejected");
        Kind k = Kind.of(r.action());
        journal((k == null ? r.action() : k.title) + " · отклонено · " + reason + viewer(r));
    }

    private void defer(Result out, Request r, Kind kind, String reason) {
        if (queue.size() >= MAX_QUEUE) {
            reject(out, r, "очередь заполнена");
            return;
        }
        queue.add(new Waiting(r, kind));
        mark(out, r, "deferred", reason);
        journal(kind.title + " · отложено · " + reason + viewer(r));
    }

    private void log(Request r, Kind kind, String what) {
        journal(kind.title + " · " + what + viewer(r));
    }

    private static String viewer(Request r) {
        return r.viewer() == null || r.viewer().isEmpty() ? (r.test() ? " · тест" : "") : " · " + r.viewer();
    }

    private void journal(String line) {
        long s = clock / 20;
        journal.addLast(String.format(Locale.ROOT, "%d:%02d %s", s / 60, s % 60, line));
        while (journal.size() > JOURNAL) journal.removeFirst();
    }
}
