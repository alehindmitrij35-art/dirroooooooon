package dev.dirronlive.bridge;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Map;
import org.junit.jupiter.api.Test;

class ProtocolTest {

    @Test
    void jsonRoundTripWithCyrillicAndEscapes() {
        String json = MiniJson.object("type", "gift", "giftName", "Роза \"красная\"\n", "count", 3,
                "ok", true, "none", null);
        Map<String, Object> m = MiniJson.parseObject(json);
        assertEquals("gift", m.get("type"));
        assertEquals("Роза \"красная\"\n", m.get("giftName"));
        assertEquals(3L, m.get("count"));
        assertEquals(Boolean.TRUE, m.get("ok"));
        assertTrue(m.containsKey("none"));
        assertNull(m.get("none"));
    }

    @Test
    void parsesWhatDartJsonEncodeProduces() {
        // Так подарок кодирует Dirronlive (jsonEncode из Dart).
        String fromApp = "{\"type\":\"gift\",\"id\":\"3f2b8c1e-9d4a-4c7b-8e21-5a6f0b9c2d13\","
                + "\"viewerName\":\"Тестовый зритель\",\"giftName\":\"Роза\",\"count\":1}";
        BridgeProtocol.Gift gift = BridgeProtocol.parseGift(fromApp);
        assertEquals("3f2b8c1e-9d4a-4c7b-8e21-5a6f0b9c2d13", gift.id());
        assertEquals("Тестовый зритель", gift.viewerName());
        assertEquals("Роза", gift.giftName());
        assertEquals(1, gift.count());
        assertEquals("Dirronlive • Тестовый зритель отправил «Роза» ×1", gift.overlayText());
    }

    @Test
    void parsesNestedValuesAndUnicodeEscapes() {
        Map<String, Object> m = MiniJson.parseObject(
                "{ \"a\" : {\"x\":[1,2,{\"y\":null}]}, \"b\":[], \"c\":\"\\u0420\\u043e\\u0437\\u0430\", \"d\":-1.5e2 }");
        assertEquals("{x=[1, 2, {y=null}]}", String.valueOf(m.get("a")));
        assertEquals("[]", String.valueOf(m.get("b")));
        assertEquals("Роза", m.get("c"));
        assertEquals(-150.0, m.get("d"));
    }

    @Test
    void rejectsGarbage() {
        assertThrows(IllegalArgumentException.class, () -> MiniJson.parseObject("не json"));
        assertThrows(IllegalArgumentException.class, () -> MiniJson.parseObject("{\"a\":1"));
        assertThrows(IllegalArgumentException.class, () -> MiniJson.parseObject("{\"a\":1} x"));
        assertNull(BridgeProtocol.parseGift("мусор"));
        assertNull(BridgeProtocol.parseGift("{\"type\":\"welcome\",\"app\":\"Dirronlive\",\"protocol\":1}"));
        assertNull(BridgeProtocol.parseGift("{\"type\":\"gift\",\"id\":\"\"}"));
        assertNull(BridgeProtocol.parseGift("{\"type\":\"gift\",\"id\":5}"));
    }

    @Test
    void cleansNamesForMinecraft() {
        BridgeProtocol.Gift gift = BridgeProtocol.parseGift(
                "{\"type\":\"gift\",\"id\":\"x\",\"viewerName\":\"§kзлой§r\\u0007\",\"giftName\":\"   \",\"count\":0}");
        assertEquals("kзлойr", gift.viewerName());
        assertEquals("Подарок", gift.giftName());
        assertEquals(1, gift.count());
        String longName = "Я".repeat(200);
        assertEquals(48, BridgeProtocol.clean(longName, "?").length());
    }

    @Test
    void comboStepShowsRunningTotal() {
        BridgeProtocol.Gift step = BridgeProtocol.parseGift("{\"type\":\"gift\",\"id\":\"r:15\","
                + "\"viewerName\":\"Тестовый зритель\",\"giftName\":\"Роза\",\"count\":1,"
                + "\"combo\":true,\"comboTotal\":15}");
        assertTrue(step.isCombo());
        assertEquals(1, step.count());
        assertEquals(15, step.comboTotal());
        assertEquals("Dirronlive • Тестовый зритель отправил «Роза» ×15", step.overlayText());

        BridgeProtocol.Gift single = BridgeProtocol.parseGift(
                "{\"type\":\"gift\",\"id\":\"x\",\"viewerName\":\"Alex\",\"giftName\":\"Роза\",\"count\":5}");
        assertFalse(single.isCombo());
        assertEquals("Dirronlive • Alex отправил «Роза» ×5", single.overlayText());
    }

    @Test
    void outgoingMessages() {
        Map<String, Object> hello = MiniJson.parseObject(BridgeProtocol.hello("1.0.0", "1.21.1", true));
        assertEquals("hello", hello.get("type"));
        assertEquals(2L, hello.get("protocol"));
        assertEquals(Boolean.TRUE, hello.get("parkourActions"));
        assertEquals(Boolean.TRUE, hello.get("worldReady"));
        assertEquals(Boolean.FALSE, MiniJson.parseObject(BridgeProtocol.world(false)).get("worldReady"));
        assertEquals("abc", MiniJson.parseObject(BridgeProtocol.ack("abc")).get("id"));
    }

    @Test
    void deduplicatorRemembersRecentIds() {
        GiftDeduplicator d = new GiftDeduplicator(3);
        d.remember("1");
        d.remember("2");
        d.remember("3");
        d.remember("4");
        assertFalse(d.contains("1"));
        assertTrue(d.contains("4"));
        assertEquals(3, d.size());
    }

    @Test
    void parsesActionWithParams() {
        BridgeProtocol.Action a = BridgeProtocol.parseAction(
                "{\"type\":\"action\",\"id\":\"r1\",\"action\":\"super_push\","
                        + "\"params\":{\"direction\":\"right\",\"strength\":3,\"lift\":0.8,\"bad\":{\"x\":1}},"
                        + "\"label\":\"Роза\",\"viewerName\":\"Alex\",\"test\":true}");
        assertNotNull(a);
        assertEquals("super_push", a.action());
        assertEquals("right", a.params().get("direction"));
        assertEquals(3L, a.params().get("strength"));
        assertEquals(0.8, a.params().get("lift"));
        assertFalse(a.params().containsKey("bad"), "вложенные объекты в параметрах отбрасываются");
        assertEquals("Роза", a.label());
        assertTrue(a.test());
        assertEquals(1, a.total(), "без total — одна штука");
        assertEquals(1000, BridgeProtocol.parseAction(
                "{\"type\":\"action\",\"id\":\"r2\",\"action\":\"push\",\"total\":1000}").total());
        assertNull(BridgeProtocol.parseAction("{\"type\":\"action\",\"id\":\"x\",\"action\":\"Rm -rf\"}"));
        assertNull(BridgeProtocol.parseAction("{\"type\":\"gift\",\"id\":\"x\"}"));
    }

    @Test
    void actionResultAndParkourMessages() {
        Map<String, Object> r = MiniJson.parseObject(BridgeProtocol.actionResult("r1",
                new BridgeProtocol.ActionResult(true, "Комната 12 → 11", 11)));
        assertEquals("actionResult", r.get("type"));
        assertEquals("Комната 12 → 11", r.get("result"));
        assertEquals(11L, r.get("room"));
        Map<String, Object> p = MiniJson.parseObject(BridgeProtocol.parkour(
                new BridgeProtocol.ParkourStatus(true, 12, false, 3, 95)));
        assertEquals(12L, p.get("room"));
        assertEquals(Boolean.TRUE, p.get("available"));
    }

    @Test
    void chatMessageForGameChat() {
        BridgeProtocol.Chat c = BridgeProtocol.parseChat("{\"type\":\"chat\",\"name\":\"Mira\",\"text\":\"привет §cвсем\",\"color\":\"light_purple\"}");
        assertEquals("Mira", c.name());
        assertEquals("привет  cвсем", c.text(), "коды цвета Minecraft вырезаются");
        assertEquals("light_purple", c.color());
        assertTrue(BridgeProtocol.parseChat("{\"type\":\"chat\",\"name\":\"Mira\",\"text\":\"  \"}") == null);
        assertEquals("gold", BridgeProtocol.parseChat("{\"type\":\"chat\",\"name\":\"A\",\"text\":\"x\",\"color\":\"#fff\"}").color());
    }

    @Test
    void worldWeatherAndTime() {
        BridgeProtocol.WorldSettings w = BridgeProtocol.parseWorld("{\"type\":\"world\",\"time\":\"night\",\"weather\":\"rain\",\"freeze\":true}");
        assertEquals("night", w.time());
        assertEquals("rain", w.weather());
        assertEquals(Boolean.TRUE, w.freeze());
        assertNull(BridgeProtocol.parseWorld("{\"type\":\"world\",\"time\":\"evil\"}"));
        assertEquals("thunder", BridgeProtocol.parseWorld("{\"type\":\"world\",\"weather\":\"thunder\"}").weather());
    }

    @Test
    void skyMessages() {
        BridgeProtocol.SkyCommand c = BridgeProtocol.parseSkyCommand("{\"type\":\"skyCommand\",\"id\":\"c1\",\"cmd\":\"pause\"}");
        assertEquals("pause", c.cmd());
        assertNull(BridgeProtocol.parseSkyCommand("{\"type\":\"skyCommand\",\"cmd\":\"explode\"}"));
        BridgeProtocol.SkySettings s = BridgeProtocol.parseSkySettings(
                "{\"type\":\"skySettings\",\"profile\":\"beauty\",\"restartKey\":\"F6\",\"reduceFlashes\":true}");
        assertEquals("beauty", s.profile());
        assertEquals("F6", s.restartKey());
        assertTrue(s.reduceFlashes());
        assertEquals("R", BridgeProtocol.parseSkySettings("{\"type\":\"skySettings\",\"restartKey\":\"ctrl+alt\"}").restartKey());
        BridgeProtocol.SkyAction a = BridgeProtocol.parseSkyAction(
                "{\"type\":\"skyAction\",\"id\":\"e1\",\"action\":\"storm\",\"strength\":9,\"seconds\":999,\"repeat\":\"queue\",\"viewer\":\"Mira\"}");
        assertEquals(3.0, a.strength(), 1e-9);
        assertEquals(120, a.seconds());
        assertEquals("queue", a.repeat());
        assertNull(BridgeProtocol.parseSkyAction("{\"type\":\"skyAction\",\"action\":\"storm\"}"), "без id");
        Map<String, Object> ack = MiniJson.parseObject(BridgeProtocol.skyAck("e1", "storm", "deferred", "идёт дорогое событие"));
        assertEquals("skyAck", ack.get("type"));
        assertEquals("deferred", ack.get("state"));
        Map<String, Object> st = MiniJson.parseObject(dev.dirronlive.sky.core.SkyStatus.ABSENT.toJson());
        assertEquals("absent", st.get("map"));
        assertTrue(st.get("effects") instanceof java.util.List<?>);
        assertEquals(Boolean.TRUE, MiniJson.parseObject(BridgeProtocol.hello("1", "1.21.1", true)).get("sky"));
    }
}
